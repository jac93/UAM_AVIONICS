Generate message types from .zcm files as: 

zcm-gen --cpp adc_t.zcm 
