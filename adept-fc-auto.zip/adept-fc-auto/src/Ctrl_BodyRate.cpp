/*
 * Ctrl_BodyRate.cpp
 *
 * Code generation for model "Ctrl_BodyRate".
 *
 * Model version              : 1.4943
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Tue Nov 17 14:37:47 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#include "Ctrl_BodyRate.h"
#include "Ctrl_BodyRate_private.h"
#include <stdio.h>
#include <iostream>
#include <string.h>

const float Tfmin = 8.0;


using namespace std;

using std::string;

//extern const ConstP_Ctrl_BodyRate_T Ctrl_BodyRate_ConstP = ConstP_Ctrl_BodyRate_T() ;
ConstP_Ctrl_BodyRate_T Ctrl_BodyRate_ConstP;

typedef struct 
{
  /* Pooled Parameter (Expression: AVpara)
   * Referenced by:
   *   '<S4>/AV parameter'
   *   '<S6>/AV parameter'
   *   '<S16>/AV parameter1'
   *   '<S17>/AV parameter1'
   */
  real_T pooled5[7];

  /* Expression: Krate
   * Referenced by: '<S1>/BodyRateGain'
   */
  real_T BodyRateGain_Value[18];

  /* Pooled Parameter (Expression: AV.Jav)
   * Referenced by:
   *   '<S3>/Constant'
   *   '<S5>/Constant'
   */
  real_T pooled6[9];
} Body_Rate_Parameters;

Body_Rate_Parameters test_Body_Rate_Parameters;


void setConstantParameters(Body_Rate_Parameters *test_Body_Rate_Parameters)
{
	
	  /* Pooled Parameter (Expression: AVpara)
   * Referenced by:
   *   '<S4>/AV parameter'
   *   '<S6>/AV parameter'
   *   '<S16>/AV parameter1'
   *   '<S17>/AV parameter1'
   */
  test_Body_Rate_Parameters->pooled5[0] = 0.1048;
  test_Body_Rate_Parameters->pooled5[1] = 0.1048;
  test_Body_Rate_Parameters->pooled5[2] = 0.1048;
  test_Body_Rate_Parameters->pooled5[3] = 0.1048;
  test_Body_Rate_Parameters->pooled5[4] = 2.4;
  test_Body_Rate_Parameters->pooled5[5] = 67.0;
  test_Body_Rate_Parameters->pooled5[6] = 12.4;




  /* Expression: Krate
   * Referenced by: '<S1>/BodyRateGain'
   */
  //real_T BodyRateGain_Value[18];
  
 
  
  //Body Rate Gain Values are numerated row wise i.e BodyRateGain_Value[1] corresponds to the 1st row 2nd column, BodyRateGain_Value[2] corresponds to the 1st row 3rd column
  
    test_Body_Rate_Parameters->BodyRateGain_Value[0] = 10;
  test_Body_Rate_Parameters->BodyRateGain_Value[1] = 0;
  test_Body_Rate_Parameters->BodyRateGain_Value[2] = 0.3297;
  test_Body_Rate_Parameters->BodyRateGain_Value[3] = 0;
  test_Body_Rate_Parameters->BodyRateGain_Value[4] = 10.0;
  test_Body_Rate_Parameters->BodyRateGain_Value[5] = 0;
  test_Body_Rate_Parameters->BodyRateGain_Value[6] = -0.1806;
  test_Body_Rate_Parameters->BodyRateGain_Value[7] = 0.0;
  test_Body_Rate_Parameters->BodyRateGain_Value[8] = 5.4742;
  test_Body_Rate_Parameters->BodyRateGain_Value[9] = 0.6867;
  test_Body_Rate_Parameters->BodyRateGain_Value[10] = 0.0;
  test_Body_Rate_Parameters->BodyRateGain_Value[11] = 0.0234;
  test_Body_Rate_Parameters->BodyRateGain_Value[12] = 0.0;
  test_Body_Rate_Parameters->BodyRateGain_Value[13] = 0.663;
  test_Body_Rate_Parameters->BodyRateGain_Value[14] = 0.0;
  test_Body_Rate_Parameters->BodyRateGain_Value[15] = 0.0234;
  test_Body_Rate_Parameters->BodyRateGain_Value[16] = 0.0;
  test_Body_Rate_Parameters->BodyRateGain_Value[17] = 0.5307;
  
  // test_Body_Rate_Parameters->BodyRateGain_Value[0] = 10;
  // test_Body_Rate_Parameters->BodyRateGain_Value[1] = 0;
  // test_Body_Rate_Parameters->BodyRateGain_Value[2] = -0.1806;
  // test_Body_Rate_Parameters->BodyRateGain_Value[3] = 0.687;
  // test_Body_Rate_Parameters->BodyRateGain_Value[4] = 0.0;
  // test_Body_Rate_Parameters->BodyRateGain_Value[5] = 0.0234;
  // test_Body_Rate_Parameters->BodyRateGain_Value[6] = 0.0;
  // test_Body_Rate_Parameters->BodyRateGain_Value[7] = 10.0;
  // test_Body_Rate_Parameters->BodyRateGain_Value[8] = 0.0;
  // test_Body_Rate_Parameters->BodyRateGain_Value[9] = 0.0;
  // test_Body_Rate_Parameters->BodyRateGain_Value[10] = 0.663;
  // test_Body_Rate_Parameters->BodyRateGain_Value[11] = 0.0;
  // test_Body_Rate_Parameters->BodyRateGain_Value[12] = 0.3297;
  // test_Body_Rate_Parameters->BodyRateGain_Value[13] = 0.0;
  // test_Body_Rate_Parameters->BodyRateGain_Value[14] = 5.4742;
  // test_Body_Rate_Parameters->BodyRateGain_Value[15] = 0.0234;
  // test_Body_Rate_Parameters->BodyRateGain_Value[16] = 0.0;
  // test_Body_Rate_Parameters->BodyRateGain_Value[17] = 0.5307;




  /* Pooled Parameter (Expression: AV.Jav)
   * Referenced by:
   *   '<S3>/Constant'
   *   '<S5>/Constant'
   */
  //real_T pooled6[9];
  
  test_Body_Rate_Parameters->pooled6[0] = 15.8;
  test_Body_Rate_Parameters->pooled6[1] = 0;
  test_Body_Rate_Parameters->pooled6[2] = -2.2;
  test_Body_Rate_Parameters->pooled6[3] = 0;
  test_Body_Rate_Parameters->pooled6[4] = 17.24;
  test_Body_Rate_Parameters->pooled6[5] = 0;
  test_Body_Rate_Parameters->pooled6[6] = -2.2;
  test_Body_Rate_Parameters->pooled6[7] = 0;
  test_Body_Rate_Parameters->pooled6[8] = 21.51;
  

	
}

/* Function for MATLAB Function: '<S17>/fun solve_thrust2' */
void Ctrl_BodyRateModelClass::Ctrl_BodyRate_invNxN(const real_T x[16], real_T y
  [16])
{
  int8_T p[4];
  real_T A[16];
  int8_T ipiv[4];
  int32_T pipk;
  int32_T b_j;
  int32_T ix;
  real_T smax;
  int32_T d_k;
  int32_T iy;
  real_T b_y;
  int32_T c_ix;
  int32_T d;
  int32_T ijA;
  for (b_j = 0; b_j < 16; b_j++) {
    y[b_j] = 0.0;
    A[b_j] = x[b_j];
  }

  ipiv[0] = 1;
  ipiv[1] = 2;
  ipiv[2] = 3;
  for (b_j = 0; b_j < 3; b_j++) {
    pipk = b_j * 5;
    iy = 0;
    ix = pipk;
    smax = std::abs(A[pipk]);
    for (d_k = 2; d_k <= 4 - b_j; d_k++) {
      ix++;
      b_y = std::abs(A[ix]);
      if (b_y > smax) {
        iy = d_k - 1;
        smax = b_y;
      }
    }

    if (A[pipk + iy] != 0.0) {
      if (iy != 0) {
        iy += b_j;
        ipiv[b_j] = static_cast<int8_T>(iy + 1);
        smax = A[b_j];
        A[b_j] = A[iy];
        A[iy] = smax;
        ix = b_j + 4;
        iy += 4;
        smax = A[ix];
        A[ix] = A[iy];
        A[iy] = smax;
        ix += 4;
        iy += 4;
        smax = A[ix];
        A[ix] = A[iy];
        A[iy] = smax;
        ix += 4;
        iy += 4;
        smax = A[ix];
        A[ix] = A[iy];
        A[iy] = smax;
      }

      iy = (pipk - b_j) + 4;
      for (ix = pipk + 1; ix < iy; ix++) {
        A[ix] /= A[pipk];
      }
    }

    iy = pipk;
    ix = pipk + 4;
    for (d_k = 0; d_k <= 2 - b_j; d_k++) {
      smax = A[ix];
      if (A[ix] != 0.0) {
        c_ix = pipk + 1;
        d = (iy - b_j) + 8;
        for (ijA = iy + 5; ijA < d; ijA++) {
          A[ijA] += A[c_ix] * -smax;
          c_ix++;
        }
      }

      ix += 4;
      iy += 4;
    }
  }

  p[0] = 1;
  p[1] = 2;
  p[2] = 3;
  p[3] = 4;
  if (ipiv[0] > 1) {
    d_k = ipiv[0] - 1;
    pipk = p[d_k];
    p[d_k] = 1;
    p[0] = static_cast<int8_T>(pipk);
  }

  if (ipiv[1] > 2) {
    d_k = ipiv[1] - 1;
    pipk = p[d_k];
    p[d_k] = p[1];
    p[1] = static_cast<int8_T>(pipk);
  }

  if (ipiv[2] > 3) {
    d_k = ipiv[2] - 1;
    pipk = p[d_k];
    p[d_k] = p[2];
    p[2] = static_cast<int8_T>(pipk);
  }

  d_k = p[0] - 1;
  y[d_k << 2] = 1.0;
  for (iy = 0; iy + 1 < 5; iy++) {
    b_j = d_k << 2;
    d = b_j + iy;
    if (y[d] != 0.0) {
      for (ix = iy + 1; ix + 1 < 5; ix++) {
        c_ix = b_j + ix;
        y[c_ix] -= y[d] * A[(iy << 2) + ix];
      }
    }
  }

  pipk = p[1] - 1;
  y[((p[1] - 1) << 2) + 1] = 1.0;
  for (iy = 1; iy + 1 < 5; iy++) {
    b_j = pipk << 2;
    d = b_j + iy;
    if (y[d] != 0.0) {
      for (ix = iy + 1; ix + 1 < 5; ix++) {
        c_ix = b_j + ix;
        y[c_ix] -= y[d] * A[(iy << 2) + ix];
      }
    }
  }

  pipk = p[2] - 1;
  y[((p[2] - 1) << 2) + 2] = 1.0;
  for (iy = 2; iy + 1 < 5; iy++) {
    b_j = pipk << 2;
    d = b_j + iy;
    if (y[d] != 0.0) {
      for (ix = iy + 1; ix + 1 < 5; ix++) {
        c_ix = b_j + ix;
        y[c_ix] -= y[d] * A[(iy << 2) + ix];
      }
    }
  }

  pipk = p[3] - 1;
  c_ix = (p[3] - 1) << 2;
  y[c_ix + 3] = 1.0;
  for (iy = 3; iy + 1 < 5; iy++) {
    if (y[c_ix + iy] != 0.0) {
      for (ix = iy + 1; ix + 1 < 5; ix++) {
        b_j = pipk << 2;
        d_k = b_j + ix;
        y[d_k] -= y[b_j + iy] * A[(iy << 2) + ix];
      }
    }
  }

  for (b_j = 0; b_j < 4; b_j++) {
    pipk = b_j << 2;
    smax = y[pipk + 3];
    if (smax != 0.0) {
      y[pipk + 3] = smax / A[15];
      for (d_k = 0; d_k < 3; d_k++) {
        c_ix = d_k + pipk;
        y[c_ix] -= y[pipk + 3] * A[d_k + 12];
      }
    }

    smax = y[pipk + 2];
    if (smax != 0.0) {
      y[pipk + 2] = smax / A[10];
      for (d_k = 0; d_k < 2; d_k++) {
        c_ix = d_k + pipk;
        y[c_ix] -= y[pipk + 2] * A[d_k + 8];
      }
    }

    smax = y[pipk + 1];
    if (smax != 0.0) {
      y[pipk + 1] = smax / A[5];
      y[pipk] -= y[pipk + 1] * A[4];
    }

    if (y[pipk] != 0.0) {
      y[pipk] /= A[0];
    }
  }
}

/* Function for MATLAB Function: '<S17>/fun solve_thrust2' */
void Ctrl_BodyRateModelClass::Ctrl_BodyRate_cal_AVnc
  (coder_internal_ref_Ctrl_BodyR_T *tp, const real_T Tfi[4], const real_T
   AVpara[7], real_T nCal[3], real_T *mcCal)
{
  /* '<S26>:1:100' */
  /* '<S26>:1:101' */
  /* '<S26>:1:102' */
  /* '<S26>:1:103' */
  /* '<S26>:1:104' */
  /* '<S26>:1:107' */
  /* '<S26>:1:108' */
  /* '<S26>:1:109' */
  /* '<S26>:1:110' */
  /* '<S26>:1:113' */
  *mcCal = ((Tfi[0] + Tfi[1]) + Tfi[2]) + Tfi[3];

  /* '<S26>:1:116' */
  tp->contents[0] = (((Tfi[0] - Tfi[1]) - Tfi[2]) + Tfi[3]) * AVpara[4];
  tp->contents[1] = (((-Tfi[0] - Tfi[1]) + Tfi[2]) + Tfi[3]) * AVpara[4];
  tp->contents[2] = ((AVpara[0] * Tfi[0] - AVpara[1] * Tfi[1]) + AVpara[2] *
                     Tfi[2]) - AVpara[3] * Tfi[3];

  /* '<S26>:1:119' */
  nCal[0] = tp->contents[0];
  nCal[1] = tp->contents[1];
  nCal[2] = tp->contents[2];
}

/* Function for MATLAB Function: '<S16>/fun solve_thrustNz' */
void Ctrl_BodyRateModelClass::Ctrl_BodyRate_sort(real_T x[4], int32_T idx[4])
{
  real_T x4[4];
  int8_T idx4[4];
  int32_T ib;
  int32_T i2;
  int32_T i3;
  int32_T i4;
  int8_T perm_idx_3;
  int8_T perm_idx_2;
  int8_T perm_idx_1;
  int8_T perm_idx_0;
  real_T tmp;
  real_T tmp_0;
  idx4[0] = 1;
  x4[0] = x[0];
  idx4[1] = 2;
  x4[1] = x[1];
  idx4[2] = 3;
  x4[2] = x[2];
  idx4[3] = 4;
  x4[3] = x[3];
  if (x[0] >= x[1]) {
    ib = 1;
    i2 = 2;
  } else {
    ib = 2;
    i2 = 1;
  }

  if (x[2] >= x[3]) {
    i3 = 3;
    i4 = 4;
  } else {
    i3 = 4;
    i4 = 3;
  }

  tmp = x4[ib - 1];
  tmp_0 = x4[i3 - 1];
  if (tmp >= tmp_0) {
    tmp = x4[i2 - 1];
    if (tmp >= tmp_0) {
      perm_idx_0 = static_cast<int8_T>(ib);
      perm_idx_1 = static_cast<int8_T>(i2);
      perm_idx_2 = static_cast<int8_T>(i3);
      perm_idx_3 = static_cast<int8_T>(i4);
    } else if (tmp >= x4[i4 - 1]) {
      perm_idx_0 = static_cast<int8_T>(ib);
      perm_idx_1 = static_cast<int8_T>(i3);
      perm_idx_2 = static_cast<int8_T>(i2);
      perm_idx_3 = static_cast<int8_T>(i4);
    } else {
      perm_idx_0 = static_cast<int8_T>(ib);
      perm_idx_1 = static_cast<int8_T>(i3);
      perm_idx_2 = static_cast<int8_T>(i4);
      perm_idx_3 = static_cast<int8_T>(i2);
    }
  } else {
    tmp_0 = x4[i4 - 1];
    if (tmp >= tmp_0) {
      if (x4[i2 - 1] >= tmp_0) {
        perm_idx_0 = static_cast<int8_T>(i3);
        perm_idx_1 = static_cast<int8_T>(ib);
        perm_idx_2 = static_cast<int8_T>(i2);
        perm_idx_3 = static_cast<int8_T>(i4);
      } else {
        perm_idx_0 = static_cast<int8_T>(i3);
        perm_idx_1 = static_cast<int8_T>(ib);
        perm_idx_2 = static_cast<int8_T>(i4);
        perm_idx_3 = static_cast<int8_T>(i2);
      }
    } else {
      perm_idx_0 = static_cast<int8_T>(i3);
      perm_idx_1 = static_cast<int8_T>(i4);
      perm_idx_2 = static_cast<int8_T>(ib);
      perm_idx_3 = static_cast<int8_T>(i2);
    }
  }

  ib = perm_idx_0 - 1;
  idx[0] = idx4[ib];
  i2 = perm_idx_1 - 1;
  idx[1] = idx4[i2];
  i3 = perm_idx_2 - 1;
  idx[2] = idx4[i3];
  i4 = perm_idx_3 - 1;
  idx[3] = idx4[i4];
  x[0] = x4[ib];
  x[1] = x4[i2];
  x[2] = x4[i3];
  x[3] = x4[i4];
}

/* Function for MATLAB Function: '<S17>/fun solve_thrust2' */
void Ctrl_BodyRateModelClass::Ctrl_BodyRate_invNxN_c(const real_T x_data[],
  const int32_T x_size[2], real_T y_data[], int32_T y_size[2])
{
  int32_T n;
  int32_T p_data[3];
  real_T A_data[24];
  int32_T ipiv_data[3];
  int32_T jBcol;
  int32_T kAcol;
  real_T smax;
  int32_T iy;
  int32_T c_n;
  int32_T b_yk;
  real_T b_y;
  int32_T c_ix;
  int32_T e;
  int32_T ijA;
  int32_T ipiv_size_idx_1;
  int32_T loop_ub_tmp;
  int32_T mmj_tmp;
  n = x_size[0];
  y_size[0] = x_size[0];
  y_size[1] = x_size[1];
  loop_ub_tmp = x_size[0] * x_size[1] - 1;
  if (0 <= loop_ub_tmp) {
    std::memset(&y_data[0], 0, (loop_ub_tmp + 1) * sizeof(real_T));
    std::memcpy(&A_data[0], &x_data[0], (loop_ub_tmp + 1) * sizeof(real_T));
  }

  c_n = x_size[0];
  if (x_size[0] < 1) {
    c_n = 0;
  }

  ipiv_size_idx_1 = c_n;
  if (c_n > 0) {
    ipiv_data[0] = 1;
    b_yk = 1;
    for (loop_ub_tmp = 2; loop_ub_tmp <= c_n; loop_ub_tmp++) {
      b_yk++;
      ipiv_data[loop_ub_tmp - 1] = b_yk;
    }
  }

  if (x_size[0] < 1) {
    c_n = 0;
  } else {
    loop_ub_tmp = x_size[0] - 1;
    if (loop_ub_tmp >= x_size[0]) {
      loop_ub_tmp = x_size[0];
    }

    for (jBcol = 0; jBcol < loop_ub_tmp; jBcol++) {
      mmj_tmp = n - jBcol;
      kAcol = (n + 1) * jBcol;
      if (mmj_tmp < 1) {
        c_n = -1;
      } else {
        c_n = 0;
        if (mmj_tmp > 1) {
          b_yk = kAcol;
          smax = std::abs(A_data[kAcol]);
          for (iy = 2; iy <= mmj_tmp; iy++) {
            b_yk++;
            b_y = std::abs(A_data[b_yk]);
            if (b_y > smax) {
              c_n = iy - 1;
              smax = b_y;
            }
          }
        }
      }

      if (A_data[kAcol + c_n] != 0.0) {
        if (c_n != 0) {
          iy = jBcol + c_n;
          ipiv_data[jBcol] = iy + 1;
          b_yk = jBcol;
          for (c_n = 0; c_n < n; c_n++) {
            smax = A_data[b_yk];
            A_data[b_yk] = A_data[iy];
            A_data[iy] = smax;
            b_yk += n;
            iy += n;
          }
        }

        iy = kAcol + mmj_tmp;
        for (c_n = kAcol + 1; c_n < iy; c_n++) {
          A_data[c_n] /= A_data[kAcol];
        }
      }

      c_n = kAcol + n;
      iy = c_n;
      for (b_yk = 0; b_yk <= mmj_tmp - 2; b_yk++) {
        smax = A_data[iy];
        if (A_data[iy] != 0.0) {
          c_ix = kAcol + 1;
          e = mmj_tmp + c_n;
          for (ijA = c_n + 1; ijA < e; ijA++) {
            A_data[ijA] += A_data[c_ix] * -smax;
            c_ix++;
          }
        }

        iy += n;
        c_n += n;
      }
    }

    c_n = x_size[0];
  }

  if (c_n > 0) {
    p_data[0] = 1;
    b_yk = 1;
    for (loop_ub_tmp = 2; loop_ub_tmp <= c_n; loop_ub_tmp++) {
      b_yk++;
      p_data[loop_ub_tmp - 1] = b_yk;
    }
  }

  for (loop_ub_tmp = 0; loop_ub_tmp < ipiv_size_idx_1; loop_ub_tmp++) {
    if (ipiv_data[loop_ub_tmp] > loop_ub_tmp + 1) {
      jBcol = p_data[ipiv_data[loop_ub_tmp] - 1];
      p_data[ipiv_data[loop_ub_tmp] - 1] = p_data[loop_ub_tmp];
      p_data[loop_ub_tmp] = jBcol;
    }
  }

  for (c_n = 0; c_n < n; c_n++) {
    b_yk = p_data[c_n] - 1;
    y_data[c_n + y_size[0] * (p_data[c_n] - 1)] = 1.0;
    for (loop_ub_tmp = c_n; loop_ub_tmp < n; loop_ub_tmp++) {
      if (y_data[y_size[0] * b_yk + loop_ub_tmp] != 0.0) {
        for (jBcol = loop_ub_tmp + 1; jBcol < n; jBcol++) {
          ipiv_size_idx_1 = y_size[0] * b_yk;
          mmj_tmp = ipiv_size_idx_1 + jBcol;
          y_data[mmj_tmp] -= y_data[ipiv_size_idx_1 + loop_ub_tmp] *
            A_data[x_size[0] * loop_ub_tmp + jBcol];
        }
      }
    }
  }

  if ((x_size[0] != 0) && ((x_size[0] != 0) && (x_size[1] != 0))) {
    for (loop_ub_tmp = 0; loop_ub_tmp < n; loop_ub_tmp++) {
      jBcol = n * loop_ub_tmp - 1;
      for (c_n = n; c_n > 0; c_n--) {
        kAcol = (c_n - 1) * n - 1;
        if (y_data[c_n + jBcol] != 0.0) {
          ipiv_size_idx_1 = c_n + jBcol;
          y_data[ipiv_size_idx_1] /= A_data[c_n + kAcol];
          for (iy = 1; iy - 1 <= c_n - 2; iy++) {
            mmj_tmp = iy + jBcol;
            y_data[mmj_tmp] -= y_data[ipiv_size_idx_1] * A_data[iy + kAcol];
          }
        }
      }
    }
  }
}

/* System initialize for atomic system: '<Root>/Ctrl_BodyRate' */
void Ctrl_BodyRateModelClass::Ctrl_BodyRat_Ctrl_BodyRate_Init
  (B_Ctrl_BodyRate_Ctrl_BodyRate_T *localB, DW_Ctrl_BodyRate_Ctrl_BodyRat_T
   *localDW)
{
  /* InitializeConditions for DiscreteIntegrator: '<S9>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE = Tfmin;

  /* InitializeConditions for DiscreteIntegrator: '<S9>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTATE = Tfmin;

  /* InitializeConditions for DiscreteIntegrator: '<S10>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE_p = Tfmin;

  /* InitializeConditions for DiscreteIntegrator: '<S10>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTAT_n = Tfmin;

  /* InitializeConditions for DiscreteIntegrator: '<S11>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTAT_pv = Tfmin;

  /* InitializeConditions for DiscreteIntegrator: '<S11>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTAT_p = Tfmin;

  /* InitializeConditions for DiscreteIntegrator: '<S12>/Discrete-Time Integrator' */
  localDW->DiscreteTimeIntegrator_DSTATE_h = Tfmin;

  /* InitializeConditions for DiscreteIntegrator: '<S12>/Discrete-Time Integrator1' */
  localDW->DiscreteTimeIntegrator1_DSTAT_i = Tfmin;

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay' */
  localDW->UnitDelay_DSTATE[0] = 0.0;

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay1' */
  localDW->UnitDelay1_DSTATE[0] = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<S6>/clip yaw torque' */
  /* SystemInitialize for Outport: '<S17>/TfiO' */
  localB->TfiO[0] = 0.0;

  /* End of SystemInitialize for SubSystem: '<S6>/clip yaw torque' */

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay' */
  localDW->UnitDelay_DSTATE[1] = 0.0;

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay1' */
  localDW->UnitDelay1_DSTATE[1] = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<S6>/clip yaw torque' */
  /* SystemInitialize for Outport: '<S17>/TfiO' */
  localB->TfiO[1] = 0.0;

  /* End of SystemInitialize for SubSystem: '<S6>/clip yaw torque' */

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay' */
  localDW->UnitDelay_DSTATE[2] = 0.0;

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay1' */
  localDW->UnitDelay1_DSTATE[2] = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<S6>/clip yaw torque' */
  /* SystemInitialize for Outport: '<S17>/TfiO' */
  localB->TfiO[2] = 0.0;

  /* End of SystemInitialize for SubSystem: '<S6>/clip yaw torque' */

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay' */
  localDW->UnitDelay_DSTATE[3] = 0.0;

  /* InitializeConditions for UnitDelay: '<S1>/Unit Delay1' */
  localDW->UnitDelay1_DSTATE[3] = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<S6>/clip yaw torque' */
  /* SystemInitialize for Outport: '<S17>/TfiO' */
  localB->TfiO[3] = 0.0;

  /* SystemInitialize for Outport: '<S17>/nCal' */
  localB->nCal[0] = 0.0;
  localB->nCal[1] = 0.0;
  localB->nCal[2] = 0.0;

  /* End of SystemInitialize for SubSystem: '<S6>/clip yaw torque' */

  /* SystemInitialize for Enabled SubSystem: '<S6>/Logic Tfi Out of Range after yaw clip' */
  /* SystemInitialize for Outport: '<S14>/log2_saturated' */
  localB->LogicalOperator = false;

  /* End of SystemInitialize for SubSystem: '<S6>/Logic Tfi Out of Range after yaw clip' */

  /* SystemInitialize for Enabled SubSystem: '<S6>/clip yaw torque' */
  /* SystemInitialize for Outport: '<S17>/Vout' */
  std::memset(&localB->Vout[0], 0, sizeof(real_T) << 3U);

  /* End of SystemInitialize for SubSystem: '<S6>/clip yaw torque' */

  /* SystemInitialize for Enabled SubSystem: '<S6>/clip mc' */
  /* SystemInitialize for Outport: '<S16>/Vout' */
  std::memset(&localB->Vout_n[0], 0, sizeof(real_T) << 3U);

  /* End of SystemInitialize for SubSystem: '<S6>/clip mc' */
}

/* Start for atomic system: '<Root>/Ctrl_BodyRate' */
void Ctrl_BodyRateModelClass::Ctrl_BodyRa_Ctrl_BodyRate_Start
  (DW_Ctrl_BodyRate_Ctrl_BodyRat_T *localDW)
{
  /* Start for InitialCondition: '<S6>/IC1' */
  localDW->IC1_FirstOutputTime = true;

  /* Start for InitialCondition: '<S6>/IC' */
  localDW->IC_FirstOutputTime = true;
}

/* Output and update for atomic system: '<Root>/Ctrl_BodyRate' */
void Ctrl_BodyRateModelClass::Ctrl_BodyRate_Ctrl_BodyRate(const real_T rtu_wDes
  [3], const real_T rtu_wdotDes[3], real_T rtu_mcDes, const real_T rtu_wMeas[3],
  B_Ctrl_BodyRate_Ctrl_BodyRate_T *localB, DW_Ctrl_BodyRate_Ctrl_BodyRat_T
  *localDW)
{
	
	/*	
	 std::cout <<"wDes[0]: " << rtu_wDes[0]  <<std::endl;
	 std::cout <<"wDes[1]: " << rtu_wDes[1]  <<std::endl;
	 std::cout <<"wDes[2]: " << rtu_wDes[2]  <<std::endl;
	*/
	
	/*
	int k;
	for(k=0;k<=17;k++)
	{
		
	    std::cout <<"Body Rate Gain[" << k << "] " << test_Body_Rate_Parameters.BodyRateGain_Value[k]  <<std::endl;

	}
	
	*/
	
  coder_internal_ref_Ctrl_BodyR_T tp;
  real_T At[16];
  real_T At3_data[24];
  real_T V3[3];
  real_T Tv_data[3];
  real_T idxTv;
  int32_T c;
  int32_T f;
  int32_T c_its;
  real_T y[16];
  real_T varargin_1_data[16];
  real_T varargin_2_data[8];
  real_T b_y_data[24];
  boolean_T empty_non_axis_sizes;
  int32_T m;
  int32_T aoffset;
  int32_T iidx[4];
  coder_internal_ref_Ctrl_BodyR_T tp_0;
  real_T rtb_TmpSignalConversionAtProduc[6];
  real_T rtb_TmpSignalConversionAtSFunct[4];
  boolean_T rtb_IC1;
  real_T rtb_Switch;
  real_T rtb_Switch_b;
  real_T rtb_Switch_l;
  real_T rtb_Switch_e1;
  real_T rtb_TfiO[4];
  real_T rtb_TfiOnew[4];
  real_T rtb_Add_l_tmp[3];
  real_T y_0[4];
  real_T rtu_wDes_0[6];
  int32_T loop_ub;
  int32_T At3_size[2];
  int32_T b_y_size[2];
  real_T rtb_TfiO_k_idx_0;
  real_T rtb_nCal_idx_2;
  real_T rtb_nCal_idx_1;
  real_T rtb_nCal_idx_0;
  real_T rtb_UnitDelay_idx_3;
  real_T rtb_UnitDelay_idx_2;
  real_T rtb_UnitDelay_idx_1;
  real_T rtb_UnitDelay_idx_0;
  int32_T varargin_1_size_idx_1;
  real_T rtb_TmpSignalConversionAtProd_0;
  int32_T varargin_1_data_tmp;
  int32_T varargin_1_data_tmp_0;
  int32_T V3_tmp;
  real_T TfiO_tmp;
  real_T TfiO_tmp_0;
  boolean_T guard1 = false;
  for (V3_tmp = 0; V3_tmp < 3; V3_tmp++) {
    /* Product: '<S5>/Product1' incorporates:
     *  Constant: '<S5>/Constant'
     *  Product: '<S5>/Product'
     */
    rtb_UnitDelay_idx_0 = test_Body_Rate_Parameters.pooled6[V3_tmp + 3];
    rtb_UnitDelay_idx_1 = test_Body_Rate_Parameters.pooled6[V3_tmp + 6];

    /* Product: '<S5>/Product' incorporates:
     *  Constant: '<S5>/Constant'
     *  Product: '<S3>/Product'
     */
    V3[V3_tmp] = rtb_UnitDelay_idx_1 * rtu_wDes[2] + (rtb_UnitDelay_idx_0 *
      rtu_wDes[1] + test_Body_Rate_Parameters.pooled6[V3_tmp] * rtu_wDes[0]);

    /* Product: '<S5>/Product1' incorporates:
     *  Constant: '<S5>/Constant'
     *  Product: '<S3>/Product1'
     */
    rtb_Add_l_tmp[V3_tmp] = rtb_UnitDelay_idx_1 * rtu_wdotDes[2] +
      (rtb_UnitDelay_idx_0 * rtu_wdotDes[1] +
       test_Body_Rate_Parameters.pooled6[V3_tmp] * rtu_wdotDes[0]);
  }

  /* UnitDelay: '<S1>/Unit Delay' */
  rtb_UnitDelay_idx_0 = localDW->UnitDelay_DSTATE[0];
  rtb_UnitDelay_idx_1 = localDW->UnitDelay_DSTATE[1];
  rtb_UnitDelay_idx_2 = localDW->UnitDelay_DSTATE[2];
  rtb_UnitDelay_idx_3 = localDW->UnitDelay_DSTATE[3];

  /* Switch: '<S9>/Switch' incorporates:
   *  DiscreteIntegrator: '<S9>/Discrete-Time Integrator'
   *  DiscreteIntegrator: '<S9>/Discrete-Time Integrator1'
   *  RelationalOperator: '<S9>/Relational Operator'
   *  UnitDelay: '<S1>/Unit Delay1'
   */
  if (rtb_UnitDelay_idx_0 >= localDW->UnitDelay1_DSTATE[0]) {
    rtb_Switch = localDW->DiscreteTimeIntegrator_DSTATE;
  } else {
    rtb_Switch = localDW->DiscreteTimeIntegrator1_DSTATE;
  }

  /* End of Switch: '<S9>/Switch' */

  /* Switch: '<S10>/Switch' incorporates:
   *  DiscreteIntegrator: '<S10>/Discrete-Time Integrator'
   *  DiscreteIntegrator: '<S10>/Discrete-Time Integrator1'
   *  RelationalOperator: '<S10>/Relational Operator'
   *  UnitDelay: '<S1>/Unit Delay1'
   */
  if (rtb_UnitDelay_idx_1 >= localDW->UnitDelay1_DSTATE[1]) {
    rtb_Switch_b = localDW->DiscreteTimeIntegrator_DSTATE_p;
  } else {
    rtb_Switch_b = localDW->DiscreteTimeIntegrator1_DSTAT_n;
  }

  /* End of Switch: '<S10>/Switch' */

  /* Switch: '<S11>/Switch' incorporates:
   *  DiscreteIntegrator: '<S11>/Discrete-Time Integrator'
   *  DiscreteIntegrator: '<S11>/Discrete-Time Integrator1'
   *  RelationalOperator: '<S11>/Relational Operator'
   *  UnitDelay: '<S1>/Unit Delay1'
   */
  if (rtb_UnitDelay_idx_2 >= localDW->UnitDelay1_DSTATE[2]) {
    rtb_Switch_l = localDW->DiscreteTimeIntegrator_DSTAT_pv;
  } else {
    rtb_Switch_l = localDW->DiscreteTimeIntegrator1_DSTAT_p;
  }

  /* End of Switch: '<S11>/Switch' */

  /* Switch: '<S12>/Switch' incorporates:
   *  DiscreteIntegrator: '<S12>/Discrete-Time Integrator'
   *  DiscreteIntegrator: '<S12>/Discrete-Time Integrator1'
   *  RelationalOperator: '<S12>/Relational Operator'
   *  UnitDelay: '<S1>/Unit Delay1'
   */
  if (rtb_UnitDelay_idx_3 >= localDW->UnitDelay1_DSTATE[3]) {
    rtb_Switch_e1 = localDW->DiscreteTimeIntegrator_DSTATE_h;
  } else {
    rtb_Switch_e1 = localDW->DiscreteTimeIntegrator1_DSTAT_i;
  }

  /* End of Switch: '<S12>/Switch' */

  /* Product: '<S7>/Element product' incorporates:
   *  Product: '<S13>/Element product'
   *  Product: '<S3>/Product'
   */
  /* MATLAB Function 'Ctrl_BodyRate/cal_nEst/MATLAB Function': '<S8>:1' */
  /* '<S8>:1:9' */
  /* '<S8>:1:10' */
  /* '<S8>:1:11' */
  /* '<S8>:1:12' */
  /* '<S8>:1:13' */
  /* '<S8>:1:16' */
  /* '<S8>:1:17' */
  /* '<S8>:1:18' */
  /* '<S8>:1:19' */
  /* '<S8>:1:22' */
  /* '<S8>:1:25' */
  rtb_TfiO_k_idx_0 = rtu_wDes[1] * V3[2];
  rtb_TmpSignalConversionAtProduc[0] = rtb_TfiO_k_idx_0;
  rtb_nCal_idx_0 = rtu_wDes[2] * V3[0];
  rtb_TmpSignalConversionAtProduc[1] = rtb_nCal_idx_0;
  rtb_nCal_idx_1 = rtu_wDes[0] * V3[1];
  rtb_TmpSignalConversionAtProduc[2] = rtb_nCal_idx_1;
  rtb_nCal_idx_2 = rtu_wDes[2] * V3[1];
  rtb_TmpSignalConversionAtProduc[3] = rtb_nCal_idx_2;
  idxTv = rtu_wDes[0] * V3[2];
  rtb_TmpSignalConversionAtProduc[4] = idxTv;
  rtb_TmpSignalConversionAtProd_0 = rtu_wDes[1] * V3[0];
  rtb_TmpSignalConversionAtProduc[5] = rtb_TmpSignalConversionAtProd_0;

  /* Product: '<S1>/Product' incorporates:
   *  MATLAB Function: '<S4>/MATLAB Function'
   *  Product: '<S5>/Product1'
   *  SignalConversion generated from: '<S8>/ SFunction '
   *  Sum: '<S13>/Add3'
   *  Sum: '<S1>/Add'
   *  Sum: '<S1>/Add1'
   *  Sum: '<S5>/Add'
   */
   
   //errors appear to be calculating correctly
   
  rtu_wDes_0[0] = rtu_wDes[0] - rtu_wMeas[0];
  rtu_wDes_0[3] = ((rtb_TfiO_k_idx_0 - rtb_nCal_idx_2) + rtb_Add_l_tmp[0]) -
    (((rtb_Switch - rtb_Switch_b) - rtb_Switch_l) + rtb_Switch_e1) * 2.4;
  rtu_wDes_0[1] = rtu_wDes[1] - rtu_wMeas[1];
  rtu_wDes_0[4] = ((rtb_nCal_idx_0 - idxTv) + rtb_Add_l_tmp[1]) - (((-rtb_Switch
    - rtb_Switch_b) + rtb_Switch_l) + rtb_Switch_e1) * 2.4;
  rtu_wDes_0[2] = rtu_wDes[2] - rtu_wMeas[2];
  rtu_wDes_0[5] = ((rtb_nCal_idx_1 - rtb_TmpSignalConversionAtProd_0) +
                   rtb_Add_l_tmp[2]) - (((0.1048 * rtb_Switch - 0.1048 *
    rtb_Switch_b) + 0.1048 * rtb_Switch_l) - 0.1048 * rtb_Switch_e1);
    
    /*
	 std::cout <<"u_wDes_0[0]: " << rtu_wDes_0[0]  <<std::endl;
	 std::cout <<"u_wDes_0[1]: " << rtu_wDes_0[1]  <<std::endl;
	 std::cout <<"u_wDes_0[2]: " << rtu_wDes_0[2]  <<std::endl;
	*/

	 //std::cout <<"nDes[1]: " << localB->Transpose2[1]  <<std::endl;
	 //std::cout <<"nDes[2]: " << localB->Transpose2[2]  <<std::endl;

  /* Math: '<S1>/Transpose2' incorporates:
   *  Constant: '<S1>/BodyRateGain'
   *  Product: '<S1>/Product'
   *  Product: '<S3>/Product1'
   *  Sum: '<S1>/Add2'
   *  Sum: '<S3>/Add'
   *  Sum: '<S7>/Add3'
   */
   
   //tranpose 2 is not computing desired torque correctly
   
  for (V3_tmp = 0; V3_tmp < 3; V3_tmp++) 
  {
    rtb_TfiO_k_idx_0 = 0.0;
    for (f = 0; f < 6; f++) 
	{
      rtb_TfiO_k_idx_0 += test_Body_Rate_Parameters.BodyRateGain_Value[3 * f + V3_tmp]
        * rtu_wDes_0[f];
        
     //std::cout <<"Body Rate Gain Value" << "[" << 3 * f + V3_tmp << "]" << test_Body_Rate_Parameters.BodyRateGain_Value[3 * f + V3_tmp]  <<std::endl;
     //Body Rate Gain Values are all set to zero this explains why no input is being computed as a consequence of body rate error
  
    }
	
	//std::cout <<"rtb_TfiO_k_idx_0: " << rtb_TfiO_k_idx_0  <<std::endl;
	// rtb_Tfi0_kidx_0 is 0 for each desired torque value
	
        localB->Transpose2[V3_tmp] = ((rtb_TmpSignalConversionAtProduc[V3_tmp] -
      rtb_TmpSignalConversionAtProduc[V3_tmp + 3]) + rtb_Add_l_tmp[V3_tmp]) +
     rtb_TfiO_k_idx_0; 
	 
	
	 
	 
     // std::cout << "Some Signal [" << V3_tmp << "] " << -rtb_TmpSignalConversionAtProduc[V3_tmp + 3] + rtb_Add_l_tmp[V3_tmp] << "\n";
	
	  
  }
  
  //test code gg jc 
  
  /*
  localB->Transpose2[0] = 2;
  localB->Transpose2[1] = 5;
  localB->Transpose2[2] = 0;
  */
  	

  
   

  /* End of Math: '<S1>/Transpose2' */

  /* MATLAB Function: '<S6>/fun solve_thrust1' incorporates:
   *  Constant: '<S6>/AV parameter'
   *  Sum: '<S1>/Sum3'
   */
  /* MATLAB Function 'Ctrl_BodyRate/thrust_saturation/fun solve_thrust1': '<S18>:1' */
  /* '<S18>:1:29' */
  /* '<S18>:1:18' */
  /* '<S18>:1:20' */
  /* '<S18>:1:21' */
  /* '<S18>:1:22' */
  /* '<S18>:1:23' */
  /* '<S18>:1:24' */
  /* '<S18>:1:26' */
  At[0] = 2.4;
  At[4] = -2.4;
  At[8] = -2.4;
  At[12] = 2.4;
  At[1] = -2.4;
  At[5] = -2.4;
  At[9] = 2.4;
  At[13] = 2.4;
  At[2] = 0.1048;
  At[6] = -0.1048;
  At[10] = 0.1048;
  At[14] = -0.1048;
  At[3] = 1.0;
  At[7] = 1.0;
  At[11] = 1.0;
  At[15] = 1.0;

  /* '<S18>:1:37' */
  /* '<S18>:1:38' */
  Ctrl_BodyRate_invNxN(At, y);

  /* '<S18>:1:40' */
  for (V3_tmp = 0; V3_tmp < 4; V3_tmp++) {
    rtb_nCal_idx_0 = y[V3_tmp] * localB->Transpose2[0];
    rtb_nCal_idx_1 = y[V3_tmp + 4] * localB->Transpose2[1];
    rtb_nCal_idx_2 = y[V3_tmp + 8] * localB->Transpose2[2];
    idxTv = y[V3_tmp + 12] * rtu_mcDes;
    rtb_TfiO_k_idx_0 = idxTv + (rtb_nCal_idx_2 + (rtb_nCal_idx_1 +
      rtb_nCal_idx_0));
    idxTv += rtb_nCal_idx_2 + (rtb_nCal_idx_1 + rtb_nCal_idx_0);
    y_0[V3_tmp] = idxTv;
    rtb_TfiO[V3_tmp] = rtb_TfiO_k_idx_0;
  }

  Ctrl_BodyRate_cal_AVnc(&tp, y_0, test_Body_Rate_Parameters.pooled5, V3,
    &rtb_TfiO_k_idx_0);

  /* '<S18>:1:40' */
  /* '<S18>:1:1' */
  /* '<S18>:1:42' */
  /* '<S18>:1:43' */
  rtb_nCal_idx_0 = V3[0];

  /* '<S18>:1:42' */
  /* '<S18>:1:43' */
  rtb_nCal_idx_1 = V3[1];

  /* '<S18>:1:42' */
  /* '<S18>:1:43' */
  rtb_nCal_idx_2 = V3[2];

  /* MinMax: '<S15>/MinMax1' */
  /* '<S18>:1:119' */
  if (rtb_TfiO[0] < rtb_TfiO[1]) {
    idxTv = rtb_TfiO[0];
  } else {
    idxTv = rtb_TfiO[1];
  }

  /* MinMax: '<S15>/MinMax' */
  if (rtb_TfiO[0] > rtb_TfiO[1]) {
    rtb_TmpSignalConversionAtProd_0 = rtb_TfiO[0];
  } else {
    rtb_TmpSignalConversionAtProd_0 = rtb_TfiO[1];
  }

  /* MinMax: '<S15>/MinMax1' */
  if (idxTv >= rtb_TfiO[2]) {
    idxTv = rtb_TfiO[2];
  }

  /* MinMax: '<S15>/MinMax' */
  if (rtb_TmpSignalConversionAtProd_0 <= rtb_TfiO[2]) {
    rtb_TmpSignalConversionAtProd_0 = rtb_TfiO[2];
  }

  /* MinMax: '<S15>/MinMax1' */
  if (idxTv >= rtb_TfiO[3]) {
    idxTv = rtb_TfiO[3];
  }

  /* MinMax: '<S15>/MinMax' */
  if (rtb_TmpSignalConversionAtProd_0 <= rtb_TfiO[3]) {
    rtb_TmpSignalConversionAtProd_0 = rtb_TfiO[3];
  }

  /* InitialCondition: '<S6>/IC1' incorporates:
   *  Abs: '<S15>/Abs'
   *  Constant: '<S22>/Constant'
   *  Constant: '<S23>/Constant'
   *  Constant: '<S24>/Constant'
   *  Logic: '<S15>/Logical Operator'
   *  Logic: '<S15>/Logical Operator1'
   *  MATLAB Function: '<S6>/fun solve_thrust1'
   *  MinMax: '<S15>/MinMax'
   *  MinMax: '<S15>/MinMax1'
   *  RelationalOperator: '<S22>/Compare'
   *  RelationalOperator: '<S23>/Compare'
   *  RelationalOperator: '<S24>/Compare'
   */
  if (localDW->IC1_FirstOutputTime) {
    localDW->IC1_FirstOutputTime = false;
    rtb_IC1 = false;
  } else {
    rtb_IC1 = (((idxTv <= Tfmin) || (rtb_TmpSignalConversionAtProd_0 >= 67.0)) &&
               (std::abs(V3[2]) >= 5.0));
  }

  /* End of InitialCondition: '<S6>/IC1' */

  /* Outputs for Enabled SubSystem: '<S6>/Logic Tfi Out of Range after yaw clip' incorporates:
   *  EnablePort: '<S14>/Enable'
   */
  /* Outputs for Enabled SubSystem: '<S6>/clip yaw torque' incorporates:
   *  EnablePort: '<S17>/Enable'
   */
  if (rtb_IC1) {
    /* MATLAB Function: '<S17>/fun sortBias1' */
    /* MATLAB Function 'Ctrl_BodyRate/thrust_saturation/clip yaw torque/fun sortBias1': '<S27>:1' */
    /* '<S27>:1:3' */
    /* '<S27>:1:4' */
    m = 0;

    /* '<S27>:1:7' */
    rtb_TfiOnew[0] = 0.0;
    rtb_TmpSignalConversionAtSFunct[0] = rtb_TfiO[0];
    rtb_TfiOnew[1] = 0.0;
    rtb_TmpSignalConversionAtSFunct[1] = rtb_TfiO[1];
    rtb_TfiOnew[2] = 0.0;
    rtb_TmpSignalConversionAtSFunct[2] = rtb_TfiO[2];
    rtb_TfiOnew[3] = 0.0;
    rtb_TmpSignalConversionAtSFunct[3] = rtb_TfiO[3];
    Ctrl_BodyRate_sort(rtb_TmpSignalConversionAtSFunct, iidx);
    rtb_TmpSignalConversionAtProd_0 = rtb_TfiO[0];
    if (rtb_TfiO[0] > rtb_TfiO[1]) {
      rtb_TmpSignalConversionAtProd_0 = rtb_TfiO[1];
    }

    if (rtb_TmpSignalConversionAtProd_0 > rtb_TfiO[2]) {
      rtb_TmpSignalConversionAtProd_0 = rtb_TfiO[2];
    }

    if (rtb_TmpSignalConversionAtProd_0 > rtb_TfiO[3]) {
      rtb_TmpSignalConversionAtProd_0 = rtb_TfiO[3];
    }

    if (rtb_TmpSignalConversionAtProd_0 <= Tfmin) {
      /* '<S27>:1:10' */
      /* '<S27>:1:11' */
      m = iidx[3];

      /* '<S27>:1:13' */
      /* '<S27>:1:14' */
      idxTv = rtb_TfiO[iidx[3] - 1] - 14.879999999999999;

      /* '<S27>:1:15' */
      rtb_TfiOnew[0] = rtb_TfiO[0] - idxTv;
      rtb_TfiOnew[1] = rtb_TfiO[1] - idxTv;
      rtb_TfiOnew[2] = rtb_TfiO[2] - idxTv;
      rtb_TfiOnew[3] = rtb_TfiO[3] - idxTv;
    }

    rtb_TmpSignalConversionAtProd_0 = rtb_TfiOnew[0];
    if (rtb_TfiOnew[0] < rtb_TfiOnew[1]) {
      rtb_TmpSignalConversionAtProd_0 = rtb_TfiOnew[1];
    }

    if (rtb_TmpSignalConversionAtProd_0 < rtb_TfiOnew[2]) {
      rtb_TmpSignalConversionAtProd_0 = rtb_TfiOnew[2];
    }

    if (rtb_TmpSignalConversionAtProd_0 < rtb_TfiOnew[3]) {
      rtb_TmpSignalConversionAtProd_0 = rtb_TfiOnew[3];
    }

    if (rtb_TmpSignalConversionAtProd_0 >= 67.0) {
      /* '<S27>:1:18' */
      /* '<S27>:1:19' */
      c_its = iidx[0];

      /* '<S27>:1:20' */
      rtb_TfiOnew[iidx[0] - 1] = 65.66;
    } else {
      /* '<S27>:1:22' */
      c_its = 0;
    }

    if ((c_its == 0) && (m != 0)) {
      /* '<S27>:1:25' */
      /* '<S27>:1:26' */
      c_its = m;
    }

    /* MATLAB Function: '<S17>/fun solve_thrust2' incorporates:
     *  Constant: '<S17>/AV parameter1'
     *  MATLAB Function: '<S17>/fun sortBias1'
     *  Sum: '<S1>/Sum3'
     */
    /* MATLAB Function 'Ctrl_BodyRate/thrust_saturation/clip yaw torque/fun solve_thrust2': '<S26>:1' */
    /* '<S26>:1:28' */
    /* '<S26>:1:19' */
    /* '<S26>:1:20' */
    /* '<S26>:1:21' */
    /* '<S26>:1:22' */
    /* '<S26>:1:23' */
    /* '<S26>:1:25' */
    At[0] = 2.4;
    At[4] = -2.4;
    At[8] = -2.4;
    At[12] = 2.4;
    At[1] = -2.4;
    At[5] = -2.4;
    At[9] = 2.4;
    At[13] = 2.4;
    At[2] = 0.1048;
    At[6] = -0.1048;
    At[10] = 0.1048;
    At[14] = -0.1048;
    At[3] = 1.0;
    At[7] = 1.0;
    At[11] = 1.0;
    At[15] = 1.0;
    if (c_its == 0) {
      /* '<S26>:1:31' */
      /* '<S26>:1:32' */
      Ctrl_BodyRate_invNxN(At, y);

      /* '<S26>:1:34' */
      for (V3_tmp = 0; V3_tmp < 4; V3_tmp++) {
        localB->TfiO[V3_tmp] = 0.0;
        idxTv = y[V3_tmp] * localB->Transpose2[0];
        localB->TfiO[V3_tmp] += idxTv;
        rtb_TmpSignalConversionAtProd_0 = y[V3_tmp + 4] * localB->Transpose2[1];
        localB->TfiO[V3_tmp] += rtb_TmpSignalConversionAtProd_0;
        TfiO_tmp = y[V3_tmp + 8] * localB->Transpose2[2];
        localB->TfiO[V3_tmp] += TfiO_tmp;
        TfiO_tmp_0 = y[V3_tmp + 12] * rtu_mcDes;
        localB->TfiO[V3_tmp] += TfiO_tmp_0;
        idxTv = TfiO_tmp_0 + (TfiO_tmp + (rtb_TmpSignalConversionAtProd_0 +
          idxTv));
        y_0[V3_tmp] = idxTv;
      }

      Ctrl_BodyRate_cal_AVnc(&tp_0, y_0, test_Body_Rate_Parameters.pooled5, V3,
        &localB->Vout[7]);

      /* '<S26>:1:34' */
      /* '<S26>:1:1' */
      /* '<S26>:1:36' */
      /* '<S26>:1:37' */
      localB->nCal[0] = V3[0];

      /* '<S26>:1:36' */
      /* '<S26>:1:37' */
      localB->nCal[1] = V3[1];

      /* '<S26>:1:36' */
      /* '<S26>:1:37' */
      localB->nCal[2] = V3[2];
    } else {
      if (static_cast<real_T>(c_its) + 1.0 > 4.0) {
        m = 0;
        c = 1;
        aoffset = 0;
        f = 1;
      } else {
        m = c_its;
        c = 5;
        aoffset = c_its;
        f = 5;
      }

      /* '<S26>:1:42' */
      if (1.0 > static_cast<real_T>(c_its) - 1.0) {
        loop_ub = -1;
      } else {
        loop_ub = c_its - 2;
      }

      varargin_1_size_idx_1 = (loop_ub + c) - m;
      for (V3_tmp = 0; V3_tmp <= loop_ub; V3_tmp++) {
        varargin_1_data_tmp = V3_tmp << 2;
        varargin_1_data_tmp_0 = V3_tmp << 1;
        varargin_1_data[varargin_1_data_tmp_0] = At[varargin_1_data_tmp];
        varargin_1_data[varargin_1_data_tmp_0 + 1] = At[varargin_1_data_tmp + 1];
      }

      c -= m;
      for (V3_tmp = 0; V3_tmp <= c - 2; V3_tmp++) {
        varargin_1_data_tmp = (m + V3_tmp) << 2;
        varargin_1_data_tmp_0 = ((V3_tmp + loop_ub) + 1) << 1;
        varargin_1_data[varargin_1_data_tmp_0] = At[varargin_1_data_tmp];
        varargin_1_data[varargin_1_data_tmp_0 + 1] = At[varargin_1_data_tmp + 1];
      }

      if (1.0 > static_cast<real_T>(c_its) - 1.0) {
        loop_ub = -1;
      } else {
        loop_ub = c_its - 2;
      }

      varargin_1_data_tmp = (loop_ub + f) - aoffset;
      for (V3_tmp = 0; V3_tmp <= loop_ub; V3_tmp++) {
        varargin_2_data[V3_tmp] = At[(V3_tmp << 2) + 3];
      }

      c = f - aoffset;
      for (V3_tmp = 0; V3_tmp <= c - 2; V3_tmp++) {
        varargin_2_data[(V3_tmp + loop_ub) + 1] = At[((aoffset + V3_tmp) << 2) +
          3];
      }

      if (varargin_1_size_idx_1 != 0) {
        m = varargin_1_size_idx_1;
      } else if (varargin_1_data_tmp != 0) {
        m = varargin_1_data_tmp;
      } else {
        m = 0;
      }

      empty_non_axis_sizes = (m == 0);
      if (empty_non_axis_sizes || (varargin_1_size_idx_1 != 0)) {
        c = 2;
      } else {
        c = 0;
      }

      if (empty_non_axis_sizes || (varargin_1_data_tmp != 0)) {
        aoffset = 1;
      } else {
        aoffset = 0;
      }

      At3_size[0] = c + aoffset;
      At3_size[1] = m;
      for (V3_tmp = 0; V3_tmp < m; V3_tmp++) {
        for (f = 0; f < c; f++) {
          At3_data[f + At3_size[0] * V3_tmp] = varargin_1_data[(V3_tmp << 1) + f];
        }
      }

      for (V3_tmp = 0; V3_tmp < m; V3_tmp++) {
        if (0 <= aoffset - 1) {
          At3_data[c + At3_size[0] * V3_tmp] = varargin_2_data[aoffset * V3_tmp];
        }
      }

      /* '<S26>:1:44' */
      /* '<S26>:1:45' */
      /* '<S26>:1:47' */
      idxTv = rtb_TfiOnew[c_its - 1];
      V3_tmp = (c_its - 1) << 2;
      V3[0] = localB->Transpose2[0] - At[V3_tmp] * idxTv;
      V3[1] = localB->Transpose2[1] - At[V3_tmp + 1] * idxTv;
      V3[2] = rtu_mcDes - At[V3_tmp + 3] * idxTv;

      /* '<S26>:1:49' */
      if ((At3_size[0] == 0) || (m == 0)) {
        b_y_size[0] = At3_size[0];
        b_y_size[1] = m;
        loop_ub = At3_size[0] * m - 1;
        if (0 <= loop_ub) {
          std::memcpy(&b_y_data[0], &At3_data[0], (loop_ub + 1) * sizeof(real_T));
        }
      } else {
        Ctrl_BodyRate_invNxN_c(At3_data, At3_size, b_y_data, b_y_size);
      }

      if (b_y_size[1] == 1) {
        loop_ub = b_y_size[0];
        for (V3_tmp = 0; V3_tmp < loop_ub; V3_tmp++) {
          Tv_data[V3_tmp] = 0.0;
          for (f = 0; f < 1; f++) {
            Tv_data[V3_tmp] += b_y_data[V3_tmp] * V3[0];
          }
        }
      } else {
        m = b_y_size[0];
        for (c = 0; c < m; c++) {
          Tv_data[c] = 0.0;
        }

        for (c = 0; c < b_y_size[1]; c++) {
          aoffset = c * m;
          for (f = 0; f < m; f++) {
            Tv_data[f] += b_y_data[aoffset + f] * V3[c];
          }
        }
      }

      /* '<S26>:1:59' */
      idxTv = 1.0;

      /* '<S26>:1:1' */
      /* '<S26>:1:60' */
      if (1 == c_its) {
        /* '<S26>:1:62' */
        /* '<S26>:1:63' */
        localB->TfiO[0] = rtb_TfiOnew[0];
      } else {
        /* '<S26>:1:65' */
        localB->TfiO[0] = Tv_data[0];

        /* '<S26>:1:66' */
        idxTv = Tfmin;
      }

      /* '<S26>:1:60' */
      if (2 == c_its) {
        /* '<S26>:1:62' */
        /* '<S26>:1:63' */
        localB->TfiO[1] = rtb_TfiOnew[1];
      } else {
        /* '<S26>:1:65' */
        localB->TfiO[1] = Tv_data[static_cast<int32_T>(idxTv) - 1];

        /* '<S26>:1:66' */
        idxTv++;
      }

      /* '<S26>:1:60' */
      if (3 == c_its) {
        /* '<S26>:1:62' */
        /* '<S26>:1:63' */
        localB->TfiO[2] = rtb_TfiOnew[2];
      } else {
        /* '<S26>:1:65' */
        localB->TfiO[2] = Tv_data[static_cast<int32_T>(idxTv) - 1];

        /* '<S26>:1:66' */
        idxTv++;
      }

      /* '<S26>:1:60' */
      if (4 == c_its) {
        /* '<S26>:1:62' */
        /* '<S26>:1:63' */
        localB->TfiO[3] = rtb_TfiOnew[3];
      } else {
        /* '<S26>:1:65' */
        localB->TfiO[3] = Tv_data[static_cast<int32_T>(idxTv) - 1];

        /* '<S26>:1:66' */
      }

      /* '<S26>:1:71' */
      Ctrl_BodyRate_cal_AVnc(&tp_0, localB->TfiO, test_Body_Rate_Parameters.pooled5,
        V3, &localB->Vout[7]);

      /* '<S26>:1:71' */
      if (V3[2] < 0.0) {
        idxTv = -1.0;
      } else if (V3[2] > 0.0) {
        idxTv = 1.0;
      } else {
        idxTv = V3[2];
      }

      if (std::abs(V3[2]) > 5.0 * idxTv) {
        /* '<S26>:1:74' */
        rtb_TmpSignalConversionAtProd_0 = localB->TfiO[0];
        if (localB->TfiO[0] > localB->TfiO[1]) {
          rtb_TmpSignalConversionAtProd_0 = localB->TfiO[1];
        }

        if (rtb_TmpSignalConversionAtProd_0 > localB->TfiO[2]) {
          rtb_TmpSignalConversionAtProd_0 = localB->TfiO[2];
        }

        if (rtb_TmpSignalConversionAtProd_0 > localB->TfiO[3]) {
          rtb_TmpSignalConversionAtProd_0 = localB->TfiO[3];
        }

        guard1 = false;
        if (rtb_TmpSignalConversionAtProd_0 <= Tfmin) {
          /* '<S26>:1:74' */
          guard1 = true;
        } else {
          rtb_TmpSignalConversionAtProd_0 = localB->TfiO[0];
          if (localB->TfiO[0] < localB->TfiO[1]) {
            rtb_TmpSignalConversionAtProd_0 = localB->TfiO[1];
          }

          if (rtb_TmpSignalConversionAtProd_0 < localB->TfiO[2]) {
            rtb_TmpSignalConversionAtProd_0 = localB->TfiO[2];
          }

          if (rtb_TmpSignalConversionAtProd_0 < localB->TfiO[3]) {
            rtb_TmpSignalConversionAtProd_0 = localB->TfiO[3];
          }

          if (rtb_TmpSignalConversionAtProd_0 >= 67.0) {
            /* '<S26>:1:74' */
            guard1 = true;
          }
        }

        if (guard1) {
          /* '<S26>:1:76' */
          /* '<S26>:1:77' */
          /* '<S26>:1:79' */
          Ctrl_BodyRate_invNxN(At, y);
          if (V3[2] < 0.0) {
            idxTv = -1.0;
          } else if (V3[2] > 0.0) {
            idxTv = 1.0;
          } else {
            idxTv = V3[2];
          }

          rtb_TmpSignalConversionAtSFunct[2] = 5.0 * idxTv;

          /* '<S26>:1:81' */
          for (V3_tmp = 0; V3_tmp < 4; V3_tmp++) {
            localB->TfiO[V3_tmp] = 0.0;
            idxTv = y[V3_tmp] * V3[0];
            localB->TfiO[V3_tmp] += idxTv;
            rtb_TmpSignalConversionAtProd_0 = y[V3_tmp + 4] * V3[1];
            localB->TfiO[V3_tmp] += rtb_TmpSignalConversionAtProd_0;
            TfiO_tmp = y[V3_tmp + 8] * rtb_TmpSignalConversionAtSFunct[2];
            localB->TfiO[V3_tmp] += TfiO_tmp;
            TfiO_tmp_0 = y[V3_tmp + 12] * rtu_mcDes;
            localB->TfiO[V3_tmp] += TfiO_tmp_0;
            idxTv = TfiO_tmp_0 + (TfiO_tmp + (rtb_TmpSignalConversionAtProd_0 +
              idxTv));
            y_0[V3_tmp] = idxTv;
          }

          Ctrl_BodyRate_cal_AVnc(&tp_0, y_0, test_Body_Rate_Parameters.pooled5, V3,
            &localB->Vout[7]);
            

          /* '<S26>:1:81' */
          tp_0.contents[0] = V3[0];
          tp_0.contents[1] = V3[1];
          tp_0.contents[2] = V3[2];

          /* '<S26>:1:81' */
        }
      }

      /* '<S26>:1:1' */
      /* '<S26>:1:85' */
      /* '<S26>:1:86' */
      localB->nCal[0] = tp_0.contents[0];

      /* '<S26>:1:85' */
      /* '<S26>:1:86' */
      localB->nCal[1] = tp_0.contents[1];

      /* '<S26>:1:85' */
      /* '<S26>:1:86' */
      localB->nCal[2] = tp_0.contents[2];
    }

    /* '<S26>:1:123' */
    localB->Vout[0] = localB->TfiO[0];
    localB->Vout[1] = localB->TfiO[1];
    localB->Vout[2] = localB->TfiO[2];
    localB->Vout[3] = localB->TfiO[3];
    localB->Vout[4] = localB->nCal[0];

    /* MinMax: '<S14>/MinMax1' */
    if (localB->TfiO[0] > localB->TfiO[1]) {
      rtb_TmpSignalConversionAtProd_0 = localB->TfiO[0];
    } else {
      rtb_TmpSignalConversionAtProd_0 = localB->TfiO[1];
    }

    /* MinMax: '<S14>/MinMax2' */
    if (localB->TfiO[0] < localB->TfiO[1]) {
      idxTv = localB->TfiO[0];
    } else {
      idxTv = localB->TfiO[1];
    }

    /* MATLAB Function: '<S17>/fun solve_thrust2' */
    localB->Vout[5] = localB->nCal[1];

    /* MinMax: '<S14>/MinMax1' */
    if (rtb_TmpSignalConversionAtProd_0 <= localB->TfiO[2]) {
      rtb_TmpSignalConversionAtProd_0 = localB->TfiO[2];
    }

    /* MinMax: '<S14>/MinMax2' */
    if (idxTv >= localB->TfiO[2]) {
      idxTv = localB->TfiO[2];
    }

    /* MATLAB Function: '<S17>/fun solve_thrust2' */
    localB->Vout[6] = localB->nCal[2];

    /* MinMax: '<S14>/MinMax1' */
    if (rtb_TmpSignalConversionAtProd_0 <= localB->TfiO[3]) {
      rtb_TmpSignalConversionAtProd_0 = localB->TfiO[3];
    }

    /* MinMax: '<S14>/MinMax2' */
    if (idxTv >= localB->TfiO[3]) {
      idxTv = localB->TfiO[3];
    }

    /* Logic: '<S14>/Logical Operator' incorporates:
     *  Abs: '<S14>/Abs'
     *  Constant: '<S19>/Constant'
     *  Constant: '<S20>/Constant'
     *  Constant: '<S21>/Constant'
     *  Logic: '<S14>/Logical Operator1'
     *  MinMax: '<S14>/MinMax1'
     *  MinMax: '<S14>/MinMax2'
     *  RelationalOperator: '<S19>/Compare'
     *  RelationalOperator: '<S20>/Compare'
     *  RelationalOperator: '<S21>/Compare'
     */
    localB->LogicalOperator = (((idxTv <= Tfmin) ||
      (rtb_TmpSignalConversionAtProd_0 >= 67.0)) && (std::abs(localB->nCal[2]) >=
      5.0));
  }

  /* End of Outputs for SubSystem: '<S6>/clip yaw torque' */
  /* End of Outputs for SubSystem: '<S6>/Logic Tfi Out of Range after yaw clip' */

  /* InitialCondition: '<S6>/IC' */
  if (localDW->IC_FirstOutputTime) {
    localDW->IC_FirstOutputTime = false;
    empty_non_axis_sizes = false;
  } else {
    empty_non_axis_sizes = localB->LogicalOperator;
  }

  /* End of InitialCondition: '<S6>/IC' */

  /* Outputs for Enabled SubSystem: '<S6>/clip mc' incorporates:
   *  EnablePort: '<S16>/Enable'
   */
  if (empty_non_axis_sizes) {
    /* MATLAB Function: '<S16>/fun solve_thrustNz' */
    /* MATLAB Function 'Ctrl_BodyRate/thrust_saturation/clip mc/fun solve_thrustNz': '<S25>:1' */
    /* '<S25>:1:15' */
    /* '<S25>:1:18' */
    /* '<S25>:1:19' */
    rtb_TfiOnew[0] = localB->TfiO[0];
    rtb_TfiO_k_idx_0 = localB->TfiO[0];
    rtb_TfiOnew[1] = localB->TfiO[1];
    rtb_nCal_idx_0 = localB->TfiO[1];
    rtb_TfiOnew[2] = localB->TfiO[2];
    rtb_nCal_idx_1 = localB->TfiO[2];
    rtb_TfiOnew[3] = localB->TfiO[3];
    rtb_nCal_idx_2 = localB->TfiO[3];
    rtb_TmpSignalConversionAtProd_0 = localB->TfiO[0];
    if (localB->TfiO[0] > localB->TfiO[1]) {
      rtb_TmpSignalConversionAtProd_0 = localB->TfiO[1];
    }

    if (rtb_TmpSignalConversionAtProd_0 > localB->TfiO[2]) {
      rtb_TmpSignalConversionAtProd_0 = localB->TfiO[2];
    }

    if (rtb_TmpSignalConversionAtProd_0 > localB->TfiO[3]) {
      rtb_TmpSignalConversionAtProd_0 = localB->TfiO[3];
    }

    if (rtb_TmpSignalConversionAtProd_0 <= Tfmin) {
      /* '<S25>:1:23' */
      /* '<S25>:1:24' */
      rtb_TmpSignalConversionAtSFunct[0] = localB->TfiO[0];
      rtb_TmpSignalConversionAtSFunct[1] = localB->TfiO[1];
      rtb_TmpSignalConversionAtSFunct[2] = localB->TfiO[2];
      rtb_TmpSignalConversionAtSFunct[3] = localB->TfiO[3];
      Ctrl_BodyRate_sort(rtb_TmpSignalConversionAtSFunct, iidx);

      /* '<S25>:1:25' */
      /* '<S25>:1:27' */
      /* '<S25>:1:28' */
      idxTv = localB->TfiO[iidx[3] - 1] - 14.879999999999999;

      /* '<S25>:1:29' */
      rtb_TfiOnew[0] = localB->TfiO[0] - idxTv;
      rtb_TfiOnew[1] = localB->TfiO[1] - idxTv;
      rtb_TfiOnew[2] = localB->TfiO[2] - idxTv;
      rtb_TfiOnew[3] = localB->TfiO[3] - idxTv;
    }

    /* '<S25>:1:32' */
    rtb_TmpSignalConversionAtSFunct[0] = rtb_TfiOnew[0];
    rtb_TmpSignalConversionAtSFunct[1] = rtb_TfiOnew[1];
    rtb_TmpSignalConversionAtSFunct[2] = rtb_TfiOnew[2];
    rtb_TmpSignalConversionAtSFunct[3] = rtb_TfiOnew[3];
    Ctrl_BodyRate_sort(rtb_TmpSignalConversionAtSFunct, iidx);
    rtb_TmpSignalConversionAtProd_0 = rtb_TfiOnew[0];
    if (rtb_TfiOnew[0] < rtb_TfiOnew[1]) {
      rtb_TmpSignalConversionAtProd_0 = rtb_TfiOnew[1];
    }

    if (rtb_TmpSignalConversionAtProd_0 < rtb_TfiOnew[2]) {
      rtb_TmpSignalConversionAtProd_0 = rtb_TfiOnew[2];
    }

    if (rtb_TmpSignalConversionAtProd_0 < rtb_TfiOnew[3]) {
      rtb_TmpSignalConversionAtProd_0 = rtb_TfiOnew[3];
    }

    if (rtb_TmpSignalConversionAtProd_0 >= 67.0) {
      /* '<S25>:1:34' */
      /* '<S25>:1:35' */
      /* '<S25>:1:37' */
      /* '<S25>:1:38' */
      idxTv = rtb_TfiOnew[iidx[0] - 1] - 65.66;

      /* '<S25>:1:39' */
      rtb_TfiO_k_idx_0 = rtb_TfiOnew[0] - idxTv;
      rtb_nCal_idx_0 = rtb_TfiOnew[1] - idxTv;
      rtb_nCal_idx_1 = rtb_TfiOnew[2] - idxTv;
      rtb_nCal_idx_2 = rtb_TfiOnew[3] - idxTv;
    }

    idxTv = rtb_TfiO_k_idx_0;
    if (rtb_TfiO_k_idx_0 > rtb_nCal_idx_0) {
      idxTv = rtb_nCal_idx_0;
    }

    if (idxTv > rtb_nCal_idx_1) {
      idxTv = rtb_nCal_idx_1;
    }

    if (idxTv > rtb_nCal_idx_2) {
      idxTv = rtb_nCal_idx_2;
    }

    if (idxTv <= Tfmin) {
      /* '<S25>:1:42' */
      /* '<S25>:1:45' */
      idxTv = rtb_TfiO_k_idx_0;

      /* '<S25>:1:45' */
      if (rtb_TfiO_k_idx_0 < Tfmin) {
        /* '<S25>:1:46' */
        /* '<S25>:1:47' */
        idxTv = Tfmin;
      }

      rtb_TfiO_k_idx_0 = idxTv;
      idxTv = rtb_nCal_idx_0;

      /* '<S25>:1:45' */
      if (rtb_nCal_idx_0 < Tfmin) {
        /* '<S25>:1:46' */
        /* '<S25>:1:47' */
        idxTv = Tfmin;
      }

      rtb_nCal_idx_0 = idxTv;
      idxTv = rtb_nCal_idx_1;

      /* '<S25>:1:45' */
      if (rtb_nCal_idx_1 < Tfmin) {
        /* '<S25>:1:46' */
        /* '<S25>:1:47' */
        idxTv = Tfmin;
      }

      rtb_nCal_idx_1 = idxTv;
      idxTv = rtb_nCal_idx_2;

      /* '<S25>:1:45' */
      if (rtb_nCal_idx_2 < Tfmin) {
        /* '<S25>:1:46' */
        /* '<S25>:1:47' */
        idxTv = Tfmin;
      }

      rtb_nCal_idx_2 = idxTv;

      /* '<S25>:1:51' */
    }

    /* '<S25>:1:54' */
    /* '<S25>:1:57' */
    /* '<S25>:1:66' */
    /* '<S25>:1:67' */
    /* '<S25>:1:68' */
    /* '<S25>:1:69' */
    /* '<S25>:1:70' */
    /* '<S25>:1:73' */
    /* '<S25>:1:74' */
    /* '<S25>:1:75' */
    /* '<S25>:1:76' */
    /* '<S25>:1:79' */
    /* '<S25>:1:82' */
    /* '<S25>:1:87' */
    localB->Vout_n[0] = rtb_TfiO_k_idx_0;
    localB->Vout_n[1] = rtb_nCal_idx_0;
    localB->Vout_n[2] = rtb_nCal_idx_1;
    localB->Vout_n[3] = rtb_nCal_idx_2;
    localB->Vout_n[4] = (((rtb_TfiO_k_idx_0 - rtb_nCal_idx_0) - rtb_nCal_idx_1)
                         + rtb_nCal_idx_2) * 2.4;
    localB->Vout_n[5] = (((-rtb_TfiO_k_idx_0 - rtb_nCal_idx_0) + rtb_nCal_idx_1)
                         + rtb_nCal_idx_2) * 2.4;
    localB->Vout_n[6] = ((0.1048 * rtb_TfiO_k_idx_0 - 0.1048 * rtb_nCal_idx_0) +
                         0.1048 * rtb_nCal_idx_1) - 0.1048 * rtb_nCal_idx_2;
    localB->Vout_n[7] = ((rtb_TfiO_k_idx_0 + rtb_nCal_idx_0) + rtb_nCal_idx_1) +
      rtb_nCal_idx_2;

    /* End of MATLAB Function: '<S16>/fun solve_thrustNz' */

    /* Switch: '<S6>/Switch' */
    std::memcpy(&localB->Switch[0], &localB->Vout_n[0], sizeof(real_T) << 3U);
  } else if (rtb_IC1) {
    /* Switch: '<S6>/Switch2' incorporates:
     *  Switch: '<S6>/Switch'
     */
    std::memcpy(&localB->Switch[0], &localB->Vout[0], sizeof(real_T) << 3U);
  } else {
    /* Switch: '<S6>/Switch' incorporates:
     *  MATLAB Function: '<S6>/fun solve_thrust1'
     */
    localB->Switch[0] = rtb_TfiO[0];
    localB->Switch[1] = rtb_TfiO[1];
    localB->Switch[2] = rtb_TfiO[2];
    localB->Switch[3] = rtb_TfiO[3];
    localB->Switch[4] = rtb_nCal_idx_0;
    localB->Switch[5] = rtb_nCal_idx_1;
    localB->Switch[6] = rtb_nCal_idx_2;
    localB->Switch[7] = rtb_TfiO_k_idx_0;
  }

  /* End of Outputs for SubSystem: '<S6>/clip mc' */

  /* Fcn: '<S2>/Fcn1' incorporates:
   *  Switch: '<S6>/Switch'
   *  Switch: '<S6>/Switch2'
   */
  rtb_TfiO_k_idx_0 = (((-0.00018933753294703587 * pow(localB->Switch[1], 4.0) +
                        0.030077502724574295 * pow(localB->Switch[1], 3.0)) +
                       -2.0638350076976262 * pow(localB->Switch[1], 2.0)) +
                      113.91997216683392 * localB->Switch[1]) + 948.3433762442;

  /* Saturate: '<S2>/Saturation' */
  if (rtb_TfiO_k_idx_0 > 4560.0) {
    localB->Saturation[0] = 4560.0;
  } else if (rtb_TfiO_k_idx_0 < 0.0) {
    localB->Saturation[0] = 0.0;
  } else {
    localB->Saturation[0] = rtb_TfiO_k_idx_0;
  }

  /* Fcn: '<S2>/Fcn' */
  rtb_TfiO_k_idx_0 = (((-0.00018933753294703587 * pow(localB->Switch[0], 4.0) +
                        0.030077502724574295 * pow(localB->Switch[0], 3.0)) +
                       -2.0638350076976262 * pow(localB->Switch[0], 2.0)) +
                      113.91997216683392 * localB->Switch[0]) + 948.3433762442;

  /* Saturate: '<S2>/Saturation' */
  if (rtb_TfiO_k_idx_0 > 4560.0) {
    localB->Saturation[1] = 4560.0;
  } else if (rtb_TfiO_k_idx_0 < 0.0) {
    localB->Saturation[1] = 0.0;
  } else {
    localB->Saturation[1] = rtb_TfiO_k_idx_0;
  }

  /* Fcn: '<S2>/Fcn2' */
  rtb_TfiO_k_idx_0 = (((-0.00018933753294703587 * pow(localB->Switch[2], 4.0) +
                        0.030077502724574295 * pow(localB->Switch[2], 3.0)) +
                       -2.0638350076976262 * pow(localB->Switch[2], 2.0)) +
                      113.91997216683392 * localB->Switch[2]) + 948.3433762442;

  /* Saturate: '<S2>/Saturation' */
  if (rtb_TfiO_k_idx_0 > 4560.0) {
    localB->Saturation[2] = 4560.0;
  } else if (rtb_TfiO_k_idx_0 < 0.0) {
    localB->Saturation[2] = 0.0;
  } else {
    localB->Saturation[2] = rtb_TfiO_k_idx_0;
  }

  /* Fcn: '<S2>/Fcn3' */
  rtb_TfiO_k_idx_0 = (((-0.00018933753294703587 * pow(localB->Switch[3], 4.0) +
                        0.030077502724574295 * pow(localB->Switch[3], 3.0)) +
                       -2.0638350076976262 * pow(localB->Switch[3], 2.0)) +
                      113.91997216683392 * localB->Switch[3]) + 948.3433762442;

  /* Saturate: '<S2>/Saturation' */
  if (rtb_TfiO_k_idx_0 > 4560.0) {
    localB->Saturation[3] = 4560.0;
  } else if (rtb_TfiO_k_idx_0 < 0.0) {
    localB->Saturation[3] = 0.0;
  } else {
    localB->Saturation[3] = rtb_TfiO_k_idx_0;
  }

  /* Update for DiscreteIntegrator: '<S9>/Discrete-Time Integrator' incorporates:
   *  Gain: '<S9>/Gain2'
   *  Sum: '<S9>/Sum2'
   */
  localDW->DiscreteTimeIntegrator_DSTATE += (rtb_UnitDelay_idx_0 -
    localDW->DiscreteTimeIntegrator_DSTATE) * 90.909090909090921 * 0.025;
  if (localDW->DiscreteTimeIntegrator_DSTATE >= 67.0) {
    localDW->DiscreteTimeIntegrator_DSTATE = 67.0;
  } else {
    if (localDW->DiscreteTimeIntegrator_DSTATE <= Tfmin) {
      localDW->DiscreteTimeIntegrator_DSTATE = Tfmin;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S9>/Discrete-Time Integrator' */

  /* Update for UnitDelay: '<S1>/Unit Delay' */
  localDW->UnitDelay_DSTATE[0] = localB->Switch[0];
  localDW->UnitDelay_DSTATE[1] = localB->Switch[1];
  localDW->UnitDelay_DSTATE[2] = localB->Switch[2];
  localDW->UnitDelay_DSTATE[3] = localB->Switch[3];

  /* Update for UnitDelay: '<S1>/Unit Delay1' */
  localDW->UnitDelay1_DSTATE[0] = rtb_Switch;
  localDW->UnitDelay1_DSTATE[1] = rtb_Switch_b;
  localDW->UnitDelay1_DSTATE[2] = rtb_Switch_l;
  localDW->UnitDelay1_DSTATE[3] = rtb_Switch_e1;

  /* Update for DiscreteIntegrator: '<S9>/Discrete-Time Integrator1' incorporates:
   *  Gain: '<S9>/Gain1'
   *  Sum: '<S9>/Sum1'
   */
  localDW->DiscreteTimeIntegrator1_DSTATE += (rtb_UnitDelay_idx_0 -
    localDW->DiscreteTimeIntegrator1_DSTATE) * 37.037037037037038 * 0.025;
  if (localDW->DiscreteTimeIntegrator1_DSTATE >= 67.0) {
    localDW->DiscreteTimeIntegrator1_DSTATE = 67.0;
  } else {
    if (localDW->DiscreteTimeIntegrator1_DSTATE <= Tfmin) {
      localDW->DiscreteTimeIntegrator1_DSTATE = Tfmin;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S9>/Discrete-Time Integrator1' */

  /* Update for DiscreteIntegrator: '<S10>/Discrete-Time Integrator' incorporates:
   *  Gain: '<S10>/Gain2'
   *  Sum: '<S10>/Sum2'
   */
  localDW->DiscreteTimeIntegrator_DSTATE_p += (rtb_UnitDelay_idx_1 -
    localDW->DiscreteTimeIntegrator_DSTATE_p) * 90.909090909090921 * 0.025;
  if (localDW->DiscreteTimeIntegrator_DSTATE_p >= 67.0) {
    localDW->DiscreteTimeIntegrator_DSTATE_p = 67.0;
  } else {
    if (localDW->DiscreteTimeIntegrator_DSTATE_p <= Tfmin) {
      localDW->DiscreteTimeIntegrator_DSTATE_p = Tfmin;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S10>/Discrete-Time Integrator' */

  /* Update for DiscreteIntegrator: '<S10>/Discrete-Time Integrator1' incorporates:
   *  Gain: '<S10>/Gain1'
   *  Sum: '<S10>/Sum1'
   */
  localDW->DiscreteTimeIntegrator1_DSTAT_n += (rtb_UnitDelay_idx_1 -
    localDW->DiscreteTimeIntegrator1_DSTAT_n) * 37.037037037037038 * 0.025;
  if (localDW->DiscreteTimeIntegrator1_DSTAT_n >= 67.0) {
    localDW->DiscreteTimeIntegrator1_DSTAT_n = 67.0;
  } else {
    if (localDW->DiscreteTimeIntegrator1_DSTAT_n <= Tfmin) {
      localDW->DiscreteTimeIntegrator1_DSTAT_n = Tfmin;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S10>/Discrete-Time Integrator1' */

  /* Update for DiscreteIntegrator: '<S11>/Discrete-Time Integrator' incorporates:
   *  Gain: '<S11>/Gain2'
   *  Sum: '<S11>/Sum2'
   */
  localDW->DiscreteTimeIntegrator_DSTAT_pv += (rtb_UnitDelay_idx_2 -
    localDW->DiscreteTimeIntegrator_DSTAT_pv) * 90.909090909090921 * 0.025;
  if (localDW->DiscreteTimeIntegrator_DSTAT_pv >= 67.0) {
    localDW->DiscreteTimeIntegrator_DSTAT_pv = 67.0;
  } else {
    if (localDW->DiscreteTimeIntegrator_DSTAT_pv <= Tfmin) {
      localDW->DiscreteTimeIntegrator_DSTAT_pv = Tfmin;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S11>/Discrete-Time Integrator' */

  /* Update for DiscreteIntegrator: '<S11>/Discrete-Time Integrator1' incorporates:
   *  Gain: '<S11>/Gain1'
   *  Sum: '<S11>/Sum1'
   */
  localDW->DiscreteTimeIntegrator1_DSTAT_p += (rtb_UnitDelay_idx_2 -
    localDW->DiscreteTimeIntegrator1_DSTAT_p) * 37.037037037037038 * 0.025;
  if (localDW->DiscreteTimeIntegrator1_DSTAT_p >= 67.0) {
    localDW->DiscreteTimeIntegrator1_DSTAT_p = 67.0;
  } else {
    if (localDW->DiscreteTimeIntegrator1_DSTAT_p <= Tfmin) {
      localDW->DiscreteTimeIntegrator1_DSTAT_p = Tfmin;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S11>/Discrete-Time Integrator1' */

  /* Update for DiscreteIntegrator: '<S12>/Discrete-Time Integrator' incorporates:
   *  Gain: '<S12>/Gain2'
   *  Sum: '<S12>/Sum2'
   */
  localDW->DiscreteTimeIntegrator_DSTATE_h += (rtb_UnitDelay_idx_3 -
    localDW->DiscreteTimeIntegrator_DSTATE_h) * 90.909090909090921 * 0.025;
  if (localDW->DiscreteTimeIntegrator_DSTATE_h >= 67.0) {
    localDW->DiscreteTimeIntegrator_DSTATE_h = 67.0;
  } else {
    if (localDW->DiscreteTimeIntegrator_DSTATE_h <= Tfmin) {
      localDW->DiscreteTimeIntegrator_DSTATE_h = Tfmin;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S12>/Discrete-Time Integrator' */

  /* Update for DiscreteIntegrator: '<S12>/Discrete-Time Integrator1' incorporates:
   *  Gain: '<S12>/Gain1'
   *  Sum: '<S12>/Sum1'
   */
  localDW->DiscreteTimeIntegrator1_DSTAT_i += (rtb_UnitDelay_idx_3 -
    localDW->DiscreteTimeIntegrator1_DSTAT_i) * 37.037037037037038 * 0.025;
  if (localDW->DiscreteTimeIntegrator1_DSTAT_i >= 67.0) {
    localDW->DiscreteTimeIntegrator1_DSTAT_i = 67.0;
  } else {
    if (localDW->DiscreteTimeIntegrator1_DSTAT_i <= Tfmin) {
      localDW->DiscreteTimeIntegrator1_DSTAT_i = Tfmin;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S12>/Discrete-Time Integrator1' */
}

/* Model step function */
void Ctrl_BodyRateModelClass::step()
{
  /* Outputs for Atomic SubSystem: '<Root>/Ctrl_BodyRate' */

  /* Inport: '<Root>/wDes' incorporates:
   *  Inport: '<Root>/mcDes'
   *  Inport: '<Root>/vBMeas'
   *  Inport: '<Root>/wMeas'
   *  Inport: '<Root>/wdotDes'
   */
  Ctrl_BodyRate_Ctrl_BodyRate(Ctrl_BodyRate_U.wDes, Ctrl_BodyRate_U.wdotDes,
    Ctrl_BodyRate_U.mcDes, Ctrl_BodyRate_U.wMeas,
    &Ctrl_BodyRate_B.Ctrl_BodyRate_c, &Ctrl_BodyRate_DW.Ctrl_BodyRate_c);

  /* End of Outputs for SubSystem: '<Root>/Ctrl_BodyRate' */

  /* Outport: '<Root>/RPMCmd' */
  Ctrl_BodyRate_Y.RPMCmd[0] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Saturation[0];
  Ctrl_BodyRate_Y.RPMCmd[1] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Saturation[1];
  Ctrl_BodyRate_Y.RPMCmd[2] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Saturation[2];
  Ctrl_BodyRate_Y.RPMCmd[3] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Saturation[3];

  /* Outport: '<Root>/TfiCmd' */
  Ctrl_BodyRate_Y.TfiCmd[0] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Switch[0];
  Ctrl_BodyRate_Y.TfiCmd[1] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Switch[1];
  Ctrl_BodyRate_Y.TfiCmd[2] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Switch[2];
  Ctrl_BodyRate_Y.TfiCmd[3] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Switch[3];

  /* Outport: '<Root>/nCmd' */
  Ctrl_BodyRate_Y.nCmd[0] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Switch[4];
  Ctrl_BodyRate_Y.nCmd[1] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Switch[5];
  Ctrl_BodyRate_Y.nCmd[2] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Switch[6];

  /* Outport: '<Root>/mcCmd' */
  Ctrl_BodyRate_Y.mcCmd = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Switch[7];

  /* Outport: '<Root>/nDes' */
  Ctrl_BodyRate_Y.nDes[0] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Transpose2[0];
  Ctrl_BodyRate_Y.nDes[1] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Transpose2[1];
  Ctrl_BodyRate_Y.nDes[2] = Ctrl_BodyRate_B.Ctrl_BodyRate_c.Transpose2[2];
}

/* Model initialize function */
void Ctrl_BodyRateModelClass::initialize()
{
  /* Registration code */

  /* block I/O */
  (void) std::memset((static_cast<void *>(&Ctrl_BodyRate_B)), 0,
                     sizeof(B_Ctrl_BodyRate_T));

  /* states (dwork) */
  (void) std::memset(static_cast<void *>(&Ctrl_BodyRate_DW), 0,
                     sizeof(DW_Ctrl_BodyRate_T));

  /* external inputs */
  (void)std::memset(&Ctrl_BodyRate_U, 0, sizeof(ExtU_Ctrl_BodyRate_T));

  /* external outputs */
  (void) std::memset(static_cast<void *>(&Ctrl_BodyRate_Y), 0,
                     sizeof(ExtY_Ctrl_BodyRate_T));

  /* Start for Atomic SubSystem: '<Root>/Ctrl_BodyRate' */
  Ctrl_BodyRa_Ctrl_BodyRate_Start(&Ctrl_BodyRate_DW.Ctrl_BodyRate_c);

  /* End of Start for SubSystem: '<Root>/Ctrl_BodyRate' */

  /* SystemInitialize for Atomic SubSystem: '<Root>/Ctrl_BodyRate' */
  Ctrl_BodyRat_Ctrl_BodyRate_Init(&Ctrl_BodyRate_B.Ctrl_BodyRate_c,
    &Ctrl_BodyRate_DW.Ctrl_BodyRate_c);
    
    
	setConstantParameters(&test_Body_Rate_Parameters); 
	
	/*
	int k;
	for(k=0;k<=17;k++)
	{
		
	    std::cout <<"Body Rate Gain[" << k << "] " << test_Body_Rate_Parameters.BodyRateGain_Value[k]  <<std::endl;

	}
	*/

  /* End of SystemInitialize for SubSystem: '<Root>/Ctrl_BodyRate' */
}

/* Model terminate function */
void Ctrl_BodyRateModelClass::terminate()
{
  /* (no terminate code required) */
}

/* Constructor */
Ctrl_BodyRateModelClass::Ctrl_BodyRateModelClass() : Ctrl_BodyRate_M()
{
  /* Currently there is no constructor body generated.*/
}

/* Destructor */
Ctrl_BodyRateModelClass::~Ctrl_BodyRateModelClass()
{
  /* Currently there is no destructor body generated.*/
}

/* Real-Time Model get method */
RT_MODEL_Ctrl_BodyRate_T * Ctrl_BodyRateModelClass::getRTM()
{
  return (&Ctrl_BodyRate_M);
}
