/*
 * Ctrl_BodyRate.h
 *
 * Code generation for model "Ctrl_BodyRate".
 *
 * Model version              : 1.4943
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Tue Nov 17 14:37:47 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Ctrl_BodyRate_h_
#define RTW_HEADER_Ctrl_BodyRate_h_
#include <cmath>
#include <cstring>
#include <math.h>
#ifndef Ctrl_BodyRate_COMMON_INCLUDES_
# define Ctrl_BodyRate_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* Ctrl_BodyRate_COMMON_INCLUDES_ */

#include "Ctrl_BodyRate_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals for system '<Root>/Ctrl_BodyRate' */
typedef struct {
  real_T Transpose2[3];                /* '<S1>/Transpose2' */
  real_T Switch[8];                    /* '<S6>/Switch' */
  real_T Saturation[4];                /* '<S2>/Saturation' */
  real_T TfiO[4];                      /* '<S17>/fun solve_thrust2' */
  real_T nCal[3];                      /* '<S17>/fun solve_thrust2' */
  real_T Vout[8];                      /* '<S17>/fun solve_thrust2' */
  real_T Vout_n[8];                    /* '<S16>/fun solve_thrustNz' */
  boolean_T LogicalOperator;           /* '<S14>/Logical Operator' */
} B_Ctrl_BodyRate_Ctrl_BodyRate_T;

/* Block states (default storage) for system '<Root>/Ctrl_BodyRate' */
typedef struct {
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S9>/Discrete-Time Integrator' */
  real_T UnitDelay_DSTATE[4];          /* '<S1>/Unit Delay' */
  real_T UnitDelay1_DSTATE[4];         /* '<S1>/Unit Delay1' */
  real_T DiscreteTimeIntegrator1_DSTATE;/* '<S9>/Discrete-Time Integrator1' */
  real_T DiscreteTimeIntegrator_DSTATE_p;/* '<S10>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator1_DSTAT_n;/* '<S10>/Discrete-Time Integrator1' */
  real_T DiscreteTimeIntegrator_DSTAT_pv;/* '<S11>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator1_DSTAT_p;/* '<S11>/Discrete-Time Integrator1' */
  real_T DiscreteTimeIntegrator_DSTATE_h;/* '<S12>/Discrete-Time Integrator' */
  real_T DiscreteTimeIntegrator1_DSTAT_i;/* '<S12>/Discrete-Time Integrator1' */
  boolean_T IC1_FirstOutputTime;       /* '<S6>/IC1' */
  boolean_T IC_FirstOutputTime;        /* '<S6>/IC' */
} DW_Ctrl_BodyRate_Ctrl_BodyRat_T;

/* Block signals (default storage) */
typedef struct {
  B_Ctrl_BodyRate_Ctrl_BodyRate_T Ctrl_BodyRate_c;/* '<Root>/Ctrl_BodyRate' */
} B_Ctrl_BodyRate_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  DW_Ctrl_BodyRate_Ctrl_BodyRat_T Ctrl_BodyRate_c;/* '<Root>/Ctrl_BodyRate' */
} DW_Ctrl_BodyRate_T;

/* Constant parameters (default storage) */
typedef struct {
  /* Pooled Parameter (Expression: AVpara)
   * Referenced by:
   *   '<S4>/AV parameter'
   *   '<S6>/AV parameter'
   *   '<S16>/AV parameter1'
   *   '<S17>/AV parameter1'
   */
  real_T pooled5[7];

  /* Expression: Krate
   * Referenced by: '<S1>/BodyRateGain'
   */
  real_T BodyRateGain_Value[18];

  /* Pooled Parameter (Expression: AV.Jav)
   * Referenced by:
   *   '<S3>/Constant'
   *   '<S5>/Constant'
   */
  real_T pooled6[9];
} ConstP_Ctrl_BodyRate_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T wDes[3];                      /* '<Root>/wDes' */
  real_T wdotDes[3];                   /* '<Root>/wdotDes' */
  real_T mcDes;                        /* '<Root>/mcDes' */
  real_T wMeas[3];                     /* '<Root>/wMeas' */
  real_T vBMeas[3];                    /* '<Root>/vBMeas' */
} ExtU_Ctrl_BodyRate_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T RPMCmd[4];                    /* '<Root>/RPMCmd' */
  real_T TfiCmd[4];                    /* '<Root>/TfiCmd' */
  real_T nCmd[3];                      /* '<Root>/nCmd' */
  real_T mcCmd;                        /* '<Root>/mcCmd' */
  real_T nDes[3];                      /* '<Root>/nDes' */
} ExtY_Ctrl_BodyRate_T;

/* Real-time Model Data Structure */
struct tag_RTM_Ctrl_BodyRate_T {
  const char_T *errorStatus;
};

//TODO why we cant use this this way
/* Constant parameters (default storage) */
//extern ConstP_Ctrl_BodyRate_T Ctrl_BodyRate_ConstP;

/* Class declaration for model Ctrl_BodyRate */
class Ctrl_BodyRateModelClass {
  /* public data and function members */
 public:
  /* External inputs */
  ExtU_Ctrl_BodyRate_T Ctrl_BodyRate_U;

  /* External outputs */
  ExtY_Ctrl_BodyRate_T Ctrl_BodyRate_Y;

  /* model initialize function */
  void initialize();

  /* model step function */
  void step();

  /* model terminate function */
  void terminate();

  /* Constructor */
  Ctrl_BodyRateModelClass();

  /* Destructor */
  ~Ctrl_BodyRateModelClass();

  /* Real-Time Model get method */
  RT_MODEL_Ctrl_BodyRate_T * getRTM();

  /* private data and function members */
 private:
  /* Block signals */
  B_Ctrl_BodyRate_T Ctrl_BodyRate_B;

  /* Block states */
  DW_Ctrl_BodyRate_T Ctrl_BodyRate_DW;

  /* Real-Time Model */
  RT_MODEL_Ctrl_BodyRate_T Ctrl_BodyRate_M;

  /* private member function(s) for subsystem '<Root>/Ctrl_BodyRate'*/
  void Ctrl_BodyRat_Ctrl_BodyRate_Init(B_Ctrl_BodyRate_Ctrl_BodyRate_T *localB,
    DW_Ctrl_BodyRate_Ctrl_BodyRat_T *localDW);
  void Ctrl_BodyRa_Ctrl_BodyRate_Start(DW_Ctrl_BodyRate_Ctrl_BodyRat_T *localDW);
  void Ctrl_BodyRate_Ctrl_BodyRate(const real_T rtu_wDes[3], const real_T
    rtu_wdotDes[3], real_T rtu_mcDes, const real_T rtu_wMeas[3],
    B_Ctrl_BodyRate_Ctrl_BodyRate_T *localB, DW_Ctrl_BodyRate_Ctrl_BodyRat_T
    *localDW);
  void Ctrl_BodyRate_invNxN(const real_T x[16], real_T y[16]);
  void Ctrl_BodyRate_cal_AVnc(coder_internal_ref_Ctrl_BodyR_T *tp, const real_T
    Tfi[4], const real_T AVpara[7], real_T nCal[3], real_T *mcCal);
  void Ctrl_BodyRate_sort(real_T x[4], int32_T idx[4]);
  void Ctrl_BodyRate_invNxN_c(const real_T x_data[], const int32_T x_size[2],
    real_T y_data[], int32_T y_size[2]);
};

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate')    - opens subsystem UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate
 * hilite_system('UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'UC_PANTHER_6DoFSim_subS_Clp2'
 * '<S1>'   : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate'
 * '<S2>'   : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/T2RPM'
 * '<S3>'   : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nCompes'
 * '<S4>'   : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nEst'
 * '<S5>'   : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nRef'
 * '<S6>'   : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation'
 * '<S7>'   : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nCompes/Cross Product'
 * '<S8>'   : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nEst/MATLAB Function'
 * '<S9>'   : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nEst/Subsystem'
 * '<S10>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nEst/Subsystem1'
 * '<S11>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nEst/Subsystem2'
 * '<S12>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nEst/Subsystem3'
 * '<S13>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/cal_nRef/Cross Product'
 * '<S14>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/Logic Tfi Out of Range after yaw clip'
 * '<S15>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/Logic Tfi Out of Range?'
 * '<S16>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/clip mc'
 * '<S17>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/clip yaw torque'
 * '<S18>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/fun solve_thrust1'
 * '<S19>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/Logic Tfi Out of Range after yaw clip/Compare To Constant1'
 * '<S20>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/Logic Tfi Out of Range after yaw clip/Compare To Constant2'
 * '<S21>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/Logic Tfi Out of Range after yaw clip/Compare To Constant3'
 * '<S22>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/Logic Tfi Out of Range?/Compare To Constant'
 * '<S23>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/Logic Tfi Out of Range?/Compare To Constant1'
 * '<S24>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/Logic Tfi Out of Range?/Compare To Constant2'
 * '<S25>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/clip mc/fun solve_thrustNz'
 * '<S26>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/clip yaw torque/fun solve_thrust2'
 * '<S27>'  : 'UC_PANTHER_6DoFSim_subS_Clp2/Ctrl_BodyRate/thrust_saturation/clip yaw torque/fun sortBias1'
 */
#endif                                 /* RTW_HEADER_Ctrl_BodyRate_h_ */
