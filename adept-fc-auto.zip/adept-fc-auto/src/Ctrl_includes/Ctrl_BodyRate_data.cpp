/*
 * Ctrl_BodyRate_data.cpp
 *
 * Code generation for model "Ctrl_BodyRate".
 *
 * Model version              : 1.4943
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Tue Nov 17 14:37:47 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#include "Ctrl_BodyRate.h"
#include "Ctrl_BodyRate_private.h"

/* Constant parameters (default storage) */
const ConstP_Ctrl_BodyRate_T Ctrl_BodyRate_ConstP = {
  /* Pooled Parameter (Expression: AVpara)
   * Referenced by:
   *   '<S4>/AV parameter'
   *   '<S6>/AV parameter'
   *   '<S16>/AV parameter1'
   *   '<S17>/AV parameter1'
   */
  { 0.1048, 0.1048, 0.1048, 0.1048, 2.4, 67.0, 12.4 },

  /* Expression: Krate
   * Referenced by: '<S1>/BodyRateGain'
   */
  { 1.0000000000000193, 5.443865554327765E-18, 7.9936057773011271E-15,
    -1.6227386128722419E-17, 1.000000000000002, 4.2498891355241782E-17,
    -8.2887161218826721E-14, -1.2666477826056171E-18, 0.99999999999996647,
    0.41507589952935192, 3.0012883028088228E-20, 8.81786665047431E-5,
    -1.1063806960389455E-17, 0.41499264179504014, 2.9008056075869254E-17,
    8.8178666504912156E-5, -8.5188755919968684E-19, 0.41484703580855981 },

  /* Pooled Parameter (Expression: AV.Jav)
   * Referenced by:
   *   '<S3>/Constant'
   *   '<S5>/Constant'
   */
  { 15.8, 0.0, -2.2, 0.0, 17.24, 0.0, -2.2, 0.0, 21.51 }
};
