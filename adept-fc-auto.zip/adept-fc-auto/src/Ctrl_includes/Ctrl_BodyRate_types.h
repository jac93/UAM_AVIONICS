/*
 * Ctrl_BodyRate_types.h
 *
 * Code generation for model "Ctrl_BodyRate".
 *
 * Model version              : 1.4943
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Tue Nov 17 14:37:47 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: 32-bit Generic
 * Code generation objective: Execution efficiency
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Ctrl_BodyRate_types_h_
#define RTW_HEADER_Ctrl_BodyRate_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Custom Type definition for MATLAB Function: '<S17>/fun sortBias1' */
#ifndef struct_tag_spGKsvEVm7uA89hv31XX4LH
#define struct_tag_spGKsvEVm7uA89hv31XX4LH

struct tag_spGKsvEVm7uA89hv31XX4LH
{
  uint32_T MissingPlacement;
  uint32_T ComparisonMethod;
};

#endif                                 /*struct_tag_spGKsvEVm7uA89hv31XX4LH*/

#ifndef typedef_spGKsvEVm7uA89hv31XX4LH_Ctrl__T
#define typedef_spGKsvEVm7uA89hv31XX4LH_Ctrl__T

typedef struct tag_spGKsvEVm7uA89hv31XX4LH spGKsvEVm7uA89hv31XX4LH_Ctrl__T;

#endif                               /*typedef_spGKsvEVm7uA89hv31XX4LH_Ctrl__T*/

#ifndef struct_tag_sJCxfmxS8gBOONUZjbjUd9E
#define struct_tag_sJCxfmxS8gBOONUZjbjUd9E

struct tag_sJCxfmxS8gBOONUZjbjUd9E
{
  boolean_T CaseSensitivity;
  boolean_T StructExpand;
  char_T PartialMatching[6];
  boolean_T IgnoreNulls;
};

#endif                                 /*struct_tag_sJCxfmxS8gBOONUZjbjUd9E*/

#ifndef typedef_sJCxfmxS8gBOONUZjbjUd9E_Ctrl__T
#define typedef_sJCxfmxS8gBOONUZjbjUd9E_Ctrl__T

typedef struct tag_sJCxfmxS8gBOONUZjbjUd9E sJCxfmxS8gBOONUZjbjUd9E_Ctrl__T;

#endif                               /*typedef_sJCxfmxS8gBOONUZjbjUd9E_Ctrl__T*/

/* Custom Type definition for MATLAB Function: '<S6>/fun solve_thrust1' */
#ifndef typedef_coder_internal_ref_Ctrl_BodyR_T
#define typedef_coder_internal_ref_Ctrl_BodyR_T

typedef struct {
  real_T contents[3];
} coder_internal_ref_Ctrl_BodyR_T;

#endif                               /*typedef_coder_internal_ref_Ctrl_BodyR_T*/

/* Forward declaration for rtModel */
typedef struct tag_RTM_Ctrl_BodyRate_T RT_MODEL_Ctrl_BodyRate_T;

#endif                                 /* RTW_HEADER_Ctrl_BodyRate_types_h_ */
