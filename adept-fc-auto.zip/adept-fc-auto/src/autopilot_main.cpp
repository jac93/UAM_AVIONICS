//
// Use of this file is governed by the MIT License - see adept_fc/LICENSE_MIT
//
// Copyright (c) 2019 Timothy Bretl, Aaron Perry, and Phillip Ansell
//

#include <stdio.h>
#include <iostream>
#include <unistd.h>
#include <string.h>
#include <zcm/zcm-cpp.hpp>
#include <chrono>
#include <time.h>

#include <iomanip>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <algorithm>
#include <iterator>
#include <cassert>
#include <sstream>

//message types:
#include "actuators_t.hpp"
#include "status_t.hpp"
#include "adc_data_t.hpp"
#include "rc_t.hpp"

#include "nav_data_t.hpp"
#include "nav_gps_data_t.hpp"

#include "vnins_data_t.hpp"

#include "RPM_t.hpp"

#include "stdlib.h"
#include "sys/times.h"
#include "sys/vtimes.h"



#include <stdint.h>	/* for uint64 definition */

#include <iomanip>
#include "Ctrl_BodyRate.h"

//Include PWM header files
#include "Navio2/PWM.h"
#include "Navio2/RCOutput_Navio2.h"
#include <Common/RCOutput.h>
#include "Common/Util.h"
#include <memory>



using std::string;

struct timespec newTime;



float Thrust_Des;
float *Thrust = &Thrust_Des;

float CalRPM;
float *RPMcal = &CalRPM;

float wDes[3];

const int N = 501; //based on size of array obtained from matlab i.e should match the length of the array generated from Matlab
float t[N];
float Vdes[N];

int k_count =0;

double RPM_Filt_Prev[4] = {0,0,0,0}; //initialize previous filtered rpms



class Handler
{
    public:
        ~Handler() = default;

        adc_data_t adc;
        status_t stat;
		rc_t rc_in;
		nav_data_t nav;
		nav_gps_data_t nav_gps;
		vnins_data_t vnins;

        Handler()
        {
            memset(&adc,0,sizeof(adc));
            memset(&stat, 0, sizeof(stat));
			memset(&rc_in, 0, sizeof(rc_in));
			memset(&nav, 0, sizeof(nav));
			memset(&nav_gps, 0, sizeof(nav_gps));
			memset(&vnins, 0, sizeof(vnins));

        }

        void read_adc(const zcm::ReceiveBuffer* rbuf,const string& chan,const adc_data_t *msg)
        {
            adc = *msg;
        }

        void read_stat(const zcm::ReceiveBuffer* rbuf,const string& chan,const status_t *msg)
        {
            stat = *msg;
        }
		
		void read_rc_in(const zcm::ReceiveBuffer* rbuf,const string& chan,const rc_t *msg)
        {
            rc_in = *msg;
        }
		
		void read_nav(const zcm::ReceiveBuffer* rbuf,const string& chan,const nav_data_t *msg)
        {
            nav = *msg;
        }
		
		void read_nav_gps(const zcm::ReceiveBuffer* rbuf,const string& chan,const nav_gps_data_t *msg)
        {
            nav_gps = *msg;
        }
		
		void read_vnins(const zcm::ReceiveBuffer* rbuf,const string& chan,const vnins_data_t *msg)
        {
            vnins = *msg;
        }
		
};


int getFileNumbOfChar(char *filename)
{
	
	
	
	std::ifstream ifs;
  	ifs.open (filename, std::ifstream::in);  	
  	
  	char c;
  	int k =0;
  	while(ifs.get(c))
  	{
  		k++;
	}
		    	  	
  	ifs.close();
  	
  	
  	
  	return k;
}

void getCharArrayfromTxtFile(char *filename,char *string1, int k)
{
	
	std::ifstream ifs;
  	ifs.open (filename, std::ifstream::in);
  //	char string1[k+1];
  	
  	for(int i=0;i<k;i++)
  	{
  		ifs.get(string1[i]);
	}
	
	ifs.close();
}

void convertCharArrayToFloatArray(char *string1,int N,float *array)
{
	std::string string2 = string1;

  // If possible, always prefer std::vector to naked array
std::vector<float> v;

  // Build an istream that holds the input string
  std::istringstream iss(string2);

  // Iterate over the istream, using >> to grab floats
  // and push_back to store them in the vector
  std::copy(std::istream_iterator<float>(iss),
        std::istream_iterator<float>(),
        std::back_inserter(v));
        
    for(int i = 0; i<N-1;i++)
	{
		array[i] = (float)v[i];
	}    
}


void getFloatArrayFromTxtFile(float *array, char *filename)
{
	    int k =  getFileNumbOfChar(filename);
	    char string1[k+1]; //initialize string where txt file will be written 
	    getCharArrayfromTxtFile(filename,string1,k); //get string with contents of text file
	    convertCharArrayToFloatArray(string1,502,array); //convert character array to float array




}

void writeArrayToTxtFile(char *filename, float *array, int N)
{
	std::ofstream myfile;
	myfile.open(filename);
	for(int j = 0;j<N;j++)
	{
		myfile << array[j] << ' ';
	}
    myfile.close();
	
}

double get_gps_time(Handler* adchandle)
{
    double adc_gps = adchandle->adc.time_gps;
    int64_t adc_time = adchandle->adc.time_rpi;
    int64_t rpi_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    return  adc_gps + (rpi_time - adc_time)/1000000.0;
}

void CalibrationRPM(float *CalRPM, Handler hand)
{
	float PWMmin = 982;
	float PWMmax = 2006;
	float RPMmin = 0.0;
	float RPMmax = 4560;
	
	float m = 1.0/(PWMmax-PWMmin);

	
	float scale = (float) m*(hand.rc_in.rc_chan[0]-PWMmin);
	
	//Ensure that calculated scale value sits is between 0 and 1 [0,1]
	if(scale<=0.0)
	{
		scale = 0.0;
	}
	else if (scale>=1.0)
	{
		scale = 1.0; 
	}
	
	*CalRPM = (RPMmax-RPMmin)*scale + RPMmin; //calculate desired RPM

	
	
}

void getDesiredThrust(float *Thrust,Handler hand)
{
	float PWMmin = 982;
	float PWMmax = 2006;
	float m = 1.0/(PWMmax-PWMmin);
	float scale = 0.0;
	float Tfmax = 268.0; //net maximum thrust with each motor able to exert 67 lb of force 4 motors so 67*4 = 68
	//float Tfmin = 49.6; //net minimum thrust with each motor's lowest thrust set to 12.4 lb of force
	//float Tfmin = 25.0;
	float Tfmin = 8.0;
	//float Tfmin = 0.0;

	//Calculate scale based on incoming PWM value
	//input: channel value used to set thrust i.e a PWM signal in ms corresponding to duty
	//output: a number between 0 and 1 whose value represents how the distance from min to the current PWM signal
	
	scale = (float) m*(hand.rc_in.rc_chan[0]-PWMmin);
	
	//Ensure that calculated scale value sits is between 0 and 1 [0,1]
	if(scale<=0.0)
	{
		scale = 0.0;
	}
	else if (scale>=1.0)
	{
		scale = 1.0; 
	}
	
	
	*Thrust = (Tfmax-Tfmin)*scale + Tfmin; //calculate desired thrust

}

void getDesiredWDes(float *wDes,Handler hand)
{
	float PWMmin = 982;
	float PWMmax = 2006;
	float PWMmid = ((PWMmax-PWMmin)/(2.0))+PWMmin;
	float m = 2.0/(PWMmax-PWMmin);
	float scale[3];
	float wMax = 8.144; //net maximum thrust with each motor able to exert 67 lb of force 4 motors so 67*4 = 68
	//float Tfmin = 49.6; //net minimum thrust with each motor's lowest thrust set to 12.4 lb of force
	//float Tfmin = 25.0;
	
	int k = 0;
	
	//float Tfmin = 0.0;

	//Calculate scale based on incoming PWM value
	//input: channel value used to set thrust i.e a PWM signal in ms corresponding to duty
	//output: a number between 0 and 1 whose value represents how the distance from min to the current PWM signal
	
	scale[0] = (float) m*(hand.rc_in.rc_chan[1]-PWMmid);
	scale[1] = (float) m*(hand.rc_in.rc_chan[2]-PWMmid);
	scale[2] = (float) m*(hand.rc_in.rc_chan[3]-PWMmid);


	for(k=0;k<=2;k++)
	{
			//Ensure that calculated scale value sits is between 0 and 1 [0,1]
		if(scale[k]<=-1.0)
		{
			scale[k] = -1.0;
		}
		else if (scale[k]>=1.0)
		{
			scale[k] = 1.0; 
		}
		
		wDes[k] = wMax*scale[k]; //calculate desired thrust
	
	}

	
	

}

float rpm_filt(float rpm_filt_prev,float rpm_raw_prev)
{
	float tc = 0.1;
	float dt = 1 / 100.0;
	
	float rpm_filt_curr = dt*(1/tc)*(-rpm_filt_prev+rpm_raw_prev)+rpm_filt_prev;
	
	return rpm_filt_curr;
}

void Controller_1_Step(int throttleAddValue, int errorCount, Handler hand, zcm::ZCM &zcm, actuators_t acts, Ctrl_BodyRateModelClass test_Ctrl_BodyRateModelClass, RPM_t rpms)
{
	//we get the throttle value from rc_in handle
	//int channelValue = hand.rc_in.rc_chan[throttleChannel] + throttleAddValue;
	
	int channelValue =  throttleAddValue;
	float RPM_Filt_Curr[4] = {0,0,0,0};
	float ERPMdes[4];
	
	acts.da = channelValue; //ailerons
	//acts.de = //elevators
	//acts.dr =//rudder
	
	acts.time_gps = get_gps_time(&hand);
	
	zcm.publish("ACTUATORS",&acts);
	
	
	
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wdotDes[0] = 0.0;
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wdotDes[1] = 0.0;
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wdotDes[2] = 0.0;
	
	//test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wMeas[0] = hand.vnins.wx;
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wMeas[0] = hand.vnins.wx;
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wMeas[1] = hand.vnins.wy;
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wMeas[2] = hand.vnins.wz;
	
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.vBMeas[0] = hand.vnins.vn;
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.vBMeas[1] = hand.vnins.ve;
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.vBMeas[2] = hand.vnins.vd;
	
	//reads RC in value from transmitter and uses value to determine desired thrust value
	getDesiredThrust(&Thrust_Des,hand);	
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.mcDes = Thrust_Des; //set desired thrust value
	
	getDesiredWDes(&wDes[0],hand); //update desired value
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wDes[0] = wDes[0];
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wDes[1] = wDes[1];
	test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_U.wDes[2] = wDes[2];
	
	// for(int k=0;k<3;k++)
	// {
		// std::cout << "Desired Body Rate[" << k << "] " << wDes[k] << std::endl;

	// }
	
	//std::cout << "RC Channel " << 5 << hand.rc_in.rc_chan[5] << std::endl;
	
	
	test_Ctrl_BodyRateModelClass.step();
	
	//filter updated rpm values
	for(int i =0; i<4;i++)
	{
		RPM_Filt_Curr[i] = rpm_filt(RPM_Filt_Prev[i],test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_Y.RPMCmd[i]); //update filtered rpm value
		rpms.RPM[i] = RPM_Filt_Curr[i];	//update filtered rpm value and store as message
		RPM_Filt_Prev[i] = RPM_Filt_Curr[i]; //update previous filtered value
	}
	
	// for(int k=0;k<4;k++)
	// {
		// std::cout << "Commanded Filtered RPM Value[" << k << "] " << rpms.RPM[k] << std::endl;

	// }
	
	
	ERPMdes[0] = rpms.RPM[0]*21.0;
	ERPMdes[1] = rpms.RPM[1]*21.0;
	ERPMdes[2] = rpms.RPM[2]*21.0;
	ERPMdes[3] = rpms.RPM[3]*21.0;
	
	
	zcm.publish("RPM",&rpms); //Publish updated RPM Values



	
}



int main(int argc, char *argv[])
{	

	
	Ctrl_BodyRateModelClass test_Ctrl_BodyRateModelClass = Ctrl_BodyRateModelClass();
	
	
	test_Ctrl_BodyRateModelClass.initialize();


	
	//printf("%s",string2);
	
	

	rc_t rc_in;
	actuators_t acts;
	RPM_t rpms;
	
    //initialize zcm
    zcm::ZCM zcm {"ipc"};

    //initialize message objects
    memset(&acts, 0, sizeof(acts));
    memset(&rpms,0,sizeof(rpms));

    //subscribe to incoming channels:
    Handler handlerObject;
    zcm.subscribe("STATUS",&Handler::read_stat,&handlerObject);
    zcm.subscribe("ADC_DATA",&Handler::read_adc,&handlerObject);
	zcm.subscribe("RC_IN",&Handler::read_rc_in,&handlerObject);
	zcm.subscribe("NAV_DATA",&Handler::read_nav,&handlerObject);
	zcm.subscribe("NAV_GPS_DATA",&Handler::read_nav_gps,&handlerObject);
	
	zcm.subscribe("VNINS_DATA",&Handler::read_vnins,&handlerObject);

    //for publishing state of this module
    status_t module_state;
    memset(&module_state,0,sizeof(module_state));
    module_state.module_status = 1;//module running

    //run zcm as a separate thread:
    zcm.start();

    std::cout << "autopilot started" << std::endl;

	//used for calculating diffTime
	#define BILLION 1000000000L

	//For Getting time values
	uint64_t diffTime, diffTime2;
	struct timespec startTime, endTime, bigBang;
	struct timespec req;
	float elapsTime;

	//For passing throttle value to PWM_out_main
	//const int throttleChannel = 3;
	const int throttleAddValue = 10;
	
	//We use this to check our diffTime is within desired range
	const uint64_t timeModifier = 2000000000;
	
	//This gets passed to Controller_1_Step() to monitor how many time diffTime went over timeModifier
	int errorCount = 0;
	
	clock_gettime(CLOCK_MONOTONIC, &bigBang);
	
	//Initialize PWM Variables
	int num_outputs = 4;
	
	//Initialize 4 PWM outputs corresponding to the 4 PWM pins that will receive RPM commands and output corresponding PWM values
	
	
	
/* 	char *filename_t = "t.txt";
	float t[502];
	getFloatArrayFromTxtFile(t, filename_t); //in this case t is the float array containing the time values specified in filename_t
	char *filename_netTxt = "test_code.txt";
    writeArrayToTxtFile(filename_netTxt,t, 501); */
	
	
	//control loop:
	while (!handlerObject.stat.should_exit)
	// int count = 0;
	// int stop = 10;
	// while( count < stop)

    {	
		zcm.publish("STATUS4",&module_state); 

		//run main code between clock reads for best performance and getting time reads
		//Get our first time reading for getting Delta time on each loop
		clock_gettime(CLOCK_MONOTONIC, &startTime);	
		
		//This is our function that will display info from RC_in_main and then send out throttle info to PM_out_main
		//This is also where testTempObj.step() is called
		
		
		Controller_1_Step(throttleAddValue, errorCount, handlerObject, zcm, acts, test_Ctrl_BodyRateModelClass, rpms);
		
		//Get our second time reading for getting Delta time on each loop
		clock_gettime(CLOCK_MONOTONIC, &endTime);	// mark the end time 
		
		//Get the Delta time difference
		diffTime = BILLION * (endTime.tv_sec - startTime.tv_sec) + endTime.tv_nsec - startTime.tv_nsec;
		
		//Elapsed Time
		//printf("elapsed time = %llu nanoseconds\n", (long long unsigned int) diffTime); 


	
		//If we go over our timeModifier we increase errorCount, which always gets passed on to Controller_1_Step()
		//If we are under our timeModifier we sleep using nanosleep to make up the difference
		if(diffTime > timeModifier)
		{
			errorCount++;
		}
		else 
		{
			req.tv_sec = 0;                         
			req.tv_nsec = timeModifier - diffTime;    
			nanosleep(&req , &req);
		}
		//count++;
	}
	
	
	
	test_Ctrl_BodyRateModelClass.terminate(); 
	
    module_state.module_status = 0;
    zcm.publish("STATUS4",&module_state);
	
    std::cout << "autopilot module exiting..." << std::endl;

    zcm.stop();
	
	// std::cout <<"YO YO YO after  ndes 0: " << test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_Y.nDes[0]  <<std::endl;
	// std::cout <<"YO YO YO after  1: " << test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_Y.nDes[1]  <<std::endl;
	// std::cout <<"YO YO YO after  2: " << test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_Y.nDes[2]  <<std::endl;
	
	// std::cout <<"YO YO YO after  ncmd0: " << test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_Y.nCmd[0]  <<std::endl;
	// std::cout <<"YO YO YO after  1: " << test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_Y.nCmd[1]  <<std::endl;
	// std::cout <<"YO YO YO after  2: " << test_Ctrl_BodyRateModelClass.Ctrl_BodyRate_Y.nCmd[2]  <<std::endl;

	
    return 0;
}

