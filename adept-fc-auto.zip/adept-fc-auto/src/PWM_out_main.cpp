//
// Use of this file is governed by the MIT License - see adept_fc/LICENSE_MIT
//
// Copyright (c) 2019 Timothy Bretl, Aaron Perry, and Phillip Ansell
//

//Reads in actuator commands and sends PWM commands out

#include <zcm/zcm-cpp.hpp>
#include <unistd.h>
#include <stdio.h>
#include <iostream>
#include <fstream>
#include "Navio2/PWM.h"
#include "Navio2/RCOutput_Navio2.h"
#include "Common/Util.h"
#include <memory>
#include <chrono>
//message types:
#include "pwm_t.hpp"
#include "rc_t.hpp"
#include "actuators_t.hpp"
#include "status_t.hpp"
#include "adc_data_t.hpp"
#include "vnins_data_t.hpp"
#include "RPM_t.hpp"


using std::string;

class Handler
{
    public:
        ~Handler() = default;

        rc_t rc_in;
        status_t stat;
        adc_data_t adc;
        vnins_data_t vnins;
        RPM_t rpms;
        
        double acts[11]={0};
        int mode_emergency = 0;
        int rc_emergency = 0;
        int64_t last_rc_time = 0;
        int64_t last_act_time = 0;
        int64_t last_vnins_time = 0;
        int64_t last_adc_time = 0;

        Handler()
        {
            memset(&rc_in,0,sizeof(rc_in));
            memset(&stat,0,sizeof(stat));
            memset(&adc,0,sizeof(adc));
            memset(&vnins,0,sizeof(vnins));
            memset(&rpms,0,sizeof(rpms));
        }

        void read_rc(const zcm::ReceiveBuffer* rbuf,const string& chan,const rc_t *msg)
        {
            rc_in = *msg;
            last_rc_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
        }

        void read_adc(const zcm::ReceiveBuffer* rbuf,const string& chan,const adc_data_t *msg)
        {
            adc = *msg;
            last_adc_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
        }

        void read_vn200(const zcm::ReceiveBuffer* rbuf,const string& chan,const vnins_data_t *msg)
        {
            vnins = *msg;
            last_vnins_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
        }

        void read_stat(const zcm::ReceiveBuffer* rbuf,const string& chan,const status_t *msg)
        {
            stat = *msg;
        }
        
        void read_rpms(const zcm::ReceiveBuffer* rbuf,const string& chan,const RPM_t *msg)
        {
            rpms = *msg;
        }

        void read_acts(const zcm::ReceiveBuffer* rbuf,const string& chan,const actuators_t *msg)
        {
            last_act_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
            acts[0] = msg->da;
            acts[1] = msg->de;
            acts[2] = msg->dr;
            for (int i=3;i<11;i++)
            {
                acts[i] = msg->dt[i-3];
            }
        }

};



std::unique_ptr <RCOutput> get_rcout()
{
        auto ptr = std::unique_ptr <RCOutput>{ new RCOutput_Navio2() };
        return ptr;
}



int output_scaling(const int& in_val, const double& s_min, const double& s_max, const int& in_min, const int& in_max)
{
    return (s_min + (s_max-s_min)/(in_max-in_min)*(in_val-in_min));
}

//lookup table function
void get_ctrl(int T_Lim, double current_time, double *time_vect, double *ele, double *ail, double *rud, double thr[][8], double ctr_out[11])
{

  if(current_time<T_Lim)
  { // use the multisine manuver as a delta to the manual controls
    bool foundtime = false;
    int i = 0;
    do { //loop through the time vector untill we have found the matching discrete value

      i++;

      if (current_time<time_vect[i]) { //we have found the correct time bin
        foundtime = true;
        //set the outputs:
        ctr_out[0]= ail[i-1];
        ctr_out[1] = ele[i-1];
        ctr_out[2] = rud[i-1];
        ctr_out[3] = thr[i-1][0];
        ctr_out[4] = thr[i-1][1];
		ctr_out[5] = thr[i-1][2];
		ctr_out[6] = thr[i-1][3];
		ctr_out[7] = thr[i-1][4];
		ctr_out[8] = thr[i-1][5];
		ctr_out[9] = thr[i-1][6];
		ctr_out[10] = thr[i-1][7];
      }
    } while(!foundtime);
  }
    else{ //if the maneuver is done, apply a delta of 0.0 to the manual controls
        ctr_out[0]= 0.0;
        ctr_out[1] = 0.0;
        ctr_out[2] = 0.0;
        ctr_out[3] = 0.0;
        ctr_out[4] = 0.0;
		ctr_out[5] = 0.0;
		ctr_out[6] = 0.0;
		ctr_out[7] = 0.0;
		ctr_out[8] = 0.0;
		ctr_out[9] = 0.0;
		ctr_out[10] = 0.0;
  }
  return;
}

double get_gps_time(Handler* adchandle)
{
    double adc_gps = adchandle->adc.time_gps;
    int64_t adc_time = adchandle->adc.time_rpi;
    int64_t rpi_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    return  adc_gps + (rpi_time - adc_time)/1000000.0;
}

int RPM2PWM(float RPM)
{
	float PWMmin = 982;
	float PWMmax = 2006;
	float RPMmax = 4560;
	float RPMmin = 0;
	float y;
	int PWM;
	float m;
	
	
	m = (PWMmax-PWMmin)/(RPMmax-RPMmin);
	y = m*(RPM-RPMmin)+PWMmin;
	
	PWM = (int)y;
	
	if(PWM>=PWMmax)
	{
		PWM = PWMmax;
	}
	else if(PWM<=PWMmin)
	{
		PWM = PWMmin;
	}
	
	return PWM;
	
}

int getOutputChannel(int i)
{
	int k = 0;
	int channel_array[4] = {1,0,3,2}
	k = channel_array[i];
	
	return k;
	
}

int main(int argc, char *argv[])
{
    //load configuration variables
    
    //Commented out everything except for the ZCM initialization so that there are no errors with the messaging system
    //PWM initialization and setting duty commands will now be handled in the autopilot_main.cpp
    
    
    string dump;
    int mapping[11] = {0,1,2,3,3,3,3,3,3,3,3};
    int num_outputs = 4; //change to 4 corresponding to 4 actuator commands
    int pwm_freq = 50;
    int disarm_pwm_servo = 1500;
    int disarm_pwm_esc   = 1100;
    int servo_min = 1100;
    int servo_max = 1900;
    int rc_min = 1000;
    int rc_max = 1995;
    float surface_max[11] = {0};
    float surface_min[11] = {0};
    int mode_chan = 4;
    int mode_cutoff = 1500;
    int maneuver_chan = 5;
    int gain_chan = 6;
    std::ifstream config_stream;
    
 /*   

    for(int i=3;i<11;i++)
    {
        surface_min[i] = (float)rc_min;
        surface_max[i] = (float)rc_max;
    }

	config_stream.open("./config_files/pwm_out.config");
    config_stream >> dump >> pwm_freq;
    config_stream >> dump >> disarm_pwm_servo;
    config_stream >> dump >> disarm_pwm_esc;
    config_stream >> dump >> servo_min;
    config_stream >> dump >> servo_max;
    config_stream >> dump >> surface_min[0] >> surface_min[1] >> surface_min[2];
    config_stream >> dump >> surface_max[0] >> surface_max[1] >> surface_max[2];
    config_stream >> dump >> rc_min;
    config_stream >> dump >> rc_max;
    config_stream >> dump >> mode_chan;
    config_stream >> dump >> mode_cutoff;
    config_stream >> dump >> maneuver_chan;
    config_stream >> dump >> gain_chan;
    config_stream.close();
    mode_chan --;
    maneuver_chan --;
    gain_chan --;
    
    

	//Default values given to servos from config file not working as intended, this is a temp work around using rc values
	//Eventually will need to update config file with correct values
	for(int i=0;i<3;i++)
    {
        surface_min[i] = (float)rc_min;
        surface_max[i] = (float)rc_max;
    }
	

    //load flight test maneuver:
	float k[3][11] = {0};
	int N = 501;
	int Time_Limit = 10;

    std::ifstream in_stream,gain_stream;
	gain_stream.open("./config_files/gains_multisine.dat");
    gain_stream >> dump >> k[0][0] >> dump >> k[1][0] >> dump >> k[2][0];//Read aileron gains
    gain_stream >> dump >> k[0][1] >> dump >> k[1][1] >> dump >> k[2][1];//Read elevator gains
    gain_stream >> dump >> k[0][2] >> dump >> k[1][2] >> dump >> k[2][2];//Read rudder gains
	gain_stream >> dump >> k[0][3] >> dump >> k[1][3] >> dump >> k[2][3];//Read throttle gains
    gain_stream.close();
	gain_stream.clear();
	
    for (int i=4; i<11; i++)
    {
        k[0][i] = k[0][3];
        k[1][i] = k[1][3];
        k[2][i] = k[2][3];
    }

	in_stream.open("./config_files/multisine.dat");
    in_stream >> N;
	in_stream >> Time_Limit;
	
	double elevator[N],aileron[N],rudder[N],time_vect[N], Delta_Throttle[N][8];

    for(int i=0; i<N; i++)
    {
        in_stream >> time_vect[i] >> elevator[i] >> rudder[i] >> aileron[i]
            >> Delta_Throttle[i][0] >> Delta_Throttle[i][1] >> Delta_Throttle[i][2]
            >> Delta_Throttle[i][3] >> Delta_Throttle[i][4] >> Delta_Throttle[i][5]
            >> Delta_Throttle[i][6] >> Delta_Throttle[i][7];
    }
    in_stream.close();
	in_stream.clear();

    //initialize timing variables
    std::chrono::high_resolution_clock::time_point start = std::chrono::high_resolution_clock::now();
	std::chrono::duration<double> _T; //Local time since mode switch
    int prev_status = 0;
    int man_run = 0;
    double multisine_output[11];
    int gainpick = 0;
    
    */
	

    //initialize zcm
    zcm::ZCM zcm {"ipc"};

    //structures to publish
    pwm_t pwm_comm;
    memset(&pwm_comm, 0 , sizeof(pwm_comm));

    //subscribe to incoming channels:
    Handler handlerObject,sens_handler;
    zcm.subscribe("RC_IN",&Handler::read_rc,&handlerObject);
    zcm.subscribe("STATUS",&Handler::read_stat,&handlerObject);
    zcm.subscribe("ACTUATORS",&Handler::read_acts,&handlerObject);
    zcm.subscribe("ADC_DATA",&Handler::read_adc,&sens_handler);
    zcm.subscribe("VNINS_DATA",&Handler::read_vn200,&sens_handler);
    zcm.subscribe("RPM",&Handler::read_rpms,&handlerObject);
    

	
    //for publishing stat of this module
    status_t module_stat;
    memset(&module_stat,0,sizeof(module_stat));
    module_stat.module_status = 1;//module running

    //initialize PWM outputs
    //************************************************************
    
    
    
    
    auto pwm = get_rcout();

    if (check_apm()) {
        return 1;
    }

    if (getuid()) {
        std::cout << std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count() <<
        " Not root. Please launch with Sudo." << std::endl;
    }

    for (int i=0;i<num_outputs; i++)
    {

        if( !(pwm->initialize(i)) )
        {
            return 1;
        }

        pwm->set_frequency(i, pwm_freq);

        if ( !(pwm->enable(i)) )
        {
            return 1;
        }

        usleep(50000); //without this, initialization of multiple channels fails
    }
	
	/*
    //set disarm pwm values
    for (int i = 0; i<num_outputs; i++)
    {
       if (i<=2)
       {
            pwm_comm.pwm_out[i] = disarm_pwm_servo;
       }
       else
       {
            pwm_comm.pwm_out[i] = disarm_pwm_esc;
       }
    }
    //************************************************************
    */
    

    zcm.start();

    std::cout<< "pwm_out started" << std::endl;

	/*
    //initialize emergency message loss detection
    bool message_thrown[2] = {false,false};
    handlerObject.last_act_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    handlerObject.last_rc_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    sens_handler.last_adc_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    sens_handler.last_vnins_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
    */
    
/*
    //check for an emergency startup
	std::ifstream f("./emergency_startup");
    if (f.good()){
        handlerObject.stat.armed = 1;
        std::cout << "Armed on emergency startup" << std::endl;
    }
    
    */
    

    while (!handlerObject.stat.should_exit)
    {
        zcm.publish("STATUS6",&module_stat);
               
        
        //handle emergency logic:
         int64_t current_time = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
		 /*
        //if we lose actuator, adc, or vnins data, autopilot cannot be in co
        if ((current_time-handlerObject.last_act_time < 500000) && (current_time-sens_handler.last_adc_time < 500000) && (current_time-sens_handler.last_vnins_time < 500000)) 
		{
            handlerObject.mode_emergency = 0;
            message_thrown[1] = false;
			
		//This block is commentted out so we can work around the error we were getting due to components not enabled at this time
        // } else {
            // handlerObject.mode_emergency = 1;
            // if (message_thrown[1] == false){
                // std::cout << std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count() <<
                // " WARNING: Mode emergency detected. Switching to manual flight mode." << std::endl;
                // message_thrown[1] = true;
            // }
        }
        if (current_time-handlerObject.last_rc_time < 500000) 
		{
            handlerObject.rc_emergency = 0;
            message_thrown[0] = false;
        } 
		else 
		{
            handlerObject.rc_emergency = 1;
            if (message_thrown[0] == false) 
			{
                std::cout << std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::steady_clock::now().time_since_epoch()).count() <<
                " WARNING: RC emergency detected. Switching to disarm." << std::endl;
                message_thrown[0] = true;
            }
        }
        
        */

		//These are hard coded for now to get us in the correct block of code to be in auto flight mode 
		//Need to figure out why we need Hard coded values at this time
		handlerObject.stat.armed = 1;
		handlerObject.mode_emergency = 0;
		//handlerObject.rc_in.rc_chan[mode_chan] = 1555;

        //pwm output logic
        if (handlerObject.stat.armed && handlerObject.rc_emergency == 0)
        {
            if(handlerObject.rc_in.rc_chan[5]<1500) //all  motors have same thrust (rpm) command
			{
				for (int i =0; i<num_outputs;i++)
				{
					
					
					pwm_comm.pwm_out[i] = handlerObject.rc_in.rc_chan[i]; //use throttle input to regulate output pwm
					pwm->set_duty_cycle(i, pwm_comm.pwm_out[i]);
				

				}
			}			
        
			else if(handlerObject.rc_in.rc_chan[5]>=1500)
			{
				int k = 0;
				
				for (int i =0; i<num_outputs;i++)
				{
					
					k = getOutPutChannel(i);
					pwm_comm.pwm_out[k] = RPM2PWM(handlerObject.rpms.RPM[i]); //convert desired rpm values to pwm values 
					pwm->set_duty_cycle(k, pwm_comm.pwm_out[k]);
					
					if(i==0)
					{
						std::cout << "RPM Command " <<  handlerObject.rpms.RPM[i] << std::endl;
						std::cout << "PWM Command " << 	pwm_comm.pwm_out[i] << std::endl;

					}

				}
			
			}
        }
        
		
        
        //timestamp the data
        pwm_comm.time_gps = get_gps_time(&sens_handler);
        //publish pwm values for logging
        zcm.publish("PWM_OUT", &pwm_comm);
        usleep(10000);
    }

    module_stat.module_status = 0;
    zcm.publish("STATUS6",&module_stat);

    zcm.stop();
    std::cout << "pwm_out module exiting..." << std::endl;
    return 0;
}
