# Arduino

## Installing the Ard1863 library

Clone the git repo:
https://github.com/IowaScaledEngineering/ard-ltc1863

Copy `src/Ard1863` into your system-wide `libraries` folder.
